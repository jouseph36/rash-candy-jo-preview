'use strict';

(() => {
  const { lang, t, esc, money, localize, initPreferences } = RashUI;
  const login = document.getElementById('owner-sign-in');
  let notice = '';

  async function request(path, body) {
    const response = await fetch('/api/owner/' + path, {
      credentials: 'same-origin', cache: 'no-store', signal: AbortSignal.timeout(10000),
      ...(body ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : {}),
    });
    if (!response.ok) {
      const error = new Error('Request failed');
      error.status = response.status;
      throw error;
    }
    return response.json();
  }

  if (login) {
    const error = document.getElementById('owner-login-error');
    const button = login.querySelector('button[type="submit"]');
    const render = () => {
      localize();
      document.title = 'Rash Candy Jo | ' + t('ownerLogin');
      error.textContent = notice ? t(notice) : '';
    };
    initPreferences(render);
    render();
    login.addEventListener('submit', async event => {
      event.preventDefault();
      if (button.disabled) return;
      button.disabled = true;
      const values = Object.fromEntries(new FormData(login));
      error.textContent = '';
      try {
        await request('login', values);
        location.replace('/admin');
      } catch (failure) {
        notice = failure.status === 503 ? 'setupRequired' : failure.status === 429 ? 'busy' : 'loginError';
        error.textContent = t(notice);
      } finally {
        login.elements.password.value = '';
        login.elements.totp.value = '';
        button.disabled = false;
      }
    });
    return;
  }

  const { products, places, flavors, kinds, statuses } = RashStore;
  const output = document.getElementById('owner-orders');
  const statusMessage = document.getElementById('owner-notice');
  const pagination = document.getElementById('owner-pages');
  const state = { loading: true, error: false, orders: [], page: 0, hasNext: false, updating: false };
  const formatDate = date => new Intl.DateTimeFormat(lang() === 'ar' ? 'ar-JO' : 'en-GB', {
    dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Amman',
  }).format(new Date(date));
  const name = (type, kind) => products[type][kind][lang()];

  function displayOrder(order) {
    const type = order.orderType;
    const cost = kind => products[type][kind].price;
    const items = type === 'personal' ? order.personalItems.map((item, index) => {
      const title = t('unit', { product: name(type, item.kind), number: index + 1 });
      const options = item.flavors.map(flavor => lang() === 'ar' ? flavor : flavors[flavor]).join(lang() === 'ar' ? '، ' : ', ');
      return `<li><span>${esc(title)}<small>${esc(options)}</small></span>${money(cost(item.kind))}</li>`;
    }) : kinds.filter(kind => order.supermarketItems[kind]).map(kind =>
      `<li><span>${esc(name(type, kind))} <bdi>×${order.supermarketItems[kind]}</bdi></span>${money(cost(kind) * order.supermarketItems[kind])}</li>`);
    const locationText = lang() === 'ar' ? order.governorateName : places[order.governorateId] || order.governorateName;
    const areaText = lang() === 'ar' ? order.areaName : places[order.areaId] || order.areaName;
    const fields = [
      ['date', esc(formatDate(order.createdAt))], ['scheduled', order.scheduledAt ? esc(formatDate(order.scheduledAt)) : '—'],
      ['name', `<bdi>${esc(order.customerName)}</bdi>`], ['phone', `<bdi dir="ltr">${esc(order.phone)}</bdi>`],
      ['governorate', esc(locationText)], ['area', esc(areaText)], ['address', `<bdi>${esc(order.deliveryAddress)}</bdi>`],
      ['contact', t('contact_' + order.contactMethod)], ['notes', order.notes ? `<bdi>${esc(order.notes)}</bdi>` : '—'],
    ];
    return `<article class="panel owner-order">
      <div class="owner-order-head"><h3><bdi class="order-code">${esc(order.orderCode)}</bdi></h3><span class="owner-status">${t(order.status)}</span></div>
      <p class="category">${t(type)}</p>
      <ul class="summary-list">${items.join('')}</ul>
      <dl>${fields.map(([key, value]) => `<div><dt>${t(key)}</dt><dd>${value}</dd></div>`).join('')}</dl>
      <div class="totals">
        <div><span>${t('subtotal')}</span><strong>${money(order.subtotal)}</strong></div>
        <div><span>${t('deliveryFee')}</span><strong>${order.deliveryFee ? money(order.deliveryFee) : t('free')}</strong></div>
        <div><span>${t('total')}</span><strong>${money(order.total)}</strong></div>
      </div>
      <form data-order-code="${esc(order.orderCode)}" data-revision="${order.revision}" method="post" action="/api/owner/orders/status">
        <label>${t('orderStatus')}<select name="status">${statuses.map(value => `<option value="${value}"${value === order.status ? ' selected' : ''}>${t(value)}</option>`).join('')}</select></label>
        <button class="button button-outline" type="submit"${state.updating ? ' disabled' : ''}>${t('updateStatus')}</button>
      </form>
    </article>`;
  }

  function render() {
    localize();
    document.title = 'Rash Candy Jo | ' + t('ownerTitle');
    statusMessage.textContent = notice ? t(notice) : '';
    output.setAttribute('aria-busy', String(state.loading));
    output.innerHTML = state.loading ? `<div class="skeleton" aria-hidden="true"></div><p role="status">${t('ownerLoading')}</p>`
      : state.error ? `<p class="form-error" role="alert">${t('ownerError')}</p><button class="button button-outline" type="button" data-owner-refresh>${t('retry')}</button>`
      : state.orders.length ? state.orders.map(displayOrder).join('') : `<p class="empty-box">${t('ownerEmpty')}</p>`;
    pagination.innerHTML = state.loading || state.error ? '' : [
      state.page > 0 ? `<button class="button button-outline" type="button" data-page="${state.page - 1}">${t('previousPage')}</button>` : '',
      state.hasNext ? `<button class="button button-outline" type="button" data-page="${state.page + 1}">${t('nextPage')}</button>` : '',
    ].join('');
  }

  async function load(page = state.page) {
    state.loading = true;
    state.error = false;
    render();
    try {
      const result = await request('orders?page=' + page);
      Object.assign(state, { orders: result.orders, hasNext: result.hasNext, page });
    } catch (failure) {
      state.orders = [];
      if (failure.status === 401) location.replace('/admin/sign-in');
      else state.error = true;
    } finally {
      state.loading = false;
      render();
    }
  }

  document.addEventListener('click', async event => {
    if (event.target.closest('[data-owner-refresh]') && !state.loading && !state.updating) { void load(); return; }
    const page = event.target.closest('[data-page]');
    if (page && !state.loading && !state.updating) { void load(Number(page.dataset.page)); return; }
    const logout = event.target.closest('[data-owner-logout]');
    if (!logout || logout.disabled) return;
    logout.disabled = true;
    try {
      await request('logout', {});
      location.replace('/admin/sign-in');
    } catch (failure) {
      if (failure.status === 401) location.replace('/admin/sign-in');
      else { notice = 'ownerError'; render(); }
    } finally {
      logout.disabled = false;
    }
  });

  output.addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.target;
    if (!form.matches('[data-order-code]') || state.updating) return;
    state.updating = true;
    const { orderCode, revision } = form.dataset;
    const status = form.elements.status.value;
    form.querySelector('button').disabled = true;
    try {
      await request('orders/status', { orderCode, revision: Number(revision), status });
      notice = 'statusSaved';
      await load();
    } catch (failure) {
      if (failure.status === 401) location.replace('/admin/sign-in');
      notice = 'statusError';
    } finally {
      state.updating = false;
      render();
    }
  });
  initPreferences(render);
  void load(0);
})();
