'use strict';

(() => {
  const { products, flavors, places, thresholds, limits, types, kinds, contactMethods,
    normalizePhone, lookup, calculate, itemErrors, detailErrors } = RashStore;
  const { lang, tr, t, esc, icon, money, moneyText, localize, initPreferences, policyMarkup, catalogMarkup } = RashUI;
  const $ = (id) => document.getElementById(id);
  const offline = document.querySelector('meta[name="rash-mode"]').content === 'offline';
  const historyKey = 'rash-test-order-cancellations';
  const assets = (name) => globalThis.RashOfflineAssets?.[name] || '/assets/' + name;
  const secrets = () => ({
    idempotencyKey: crypto.randomUUID(),
    cancellationToken: Array.from(crypto.getRandomValues(new Uint8Array(32)), byte => byte.toString(16).padStart(2, '0')).join(''),
  });
  const newDraft = () => ({
    orderType: 'personal', personalItems: [], supermarketItems: { cup: 0, plate: 0 },
    governorateId: '', areaId: '', customerName: '', phone: '', deliveryAddress: '', contactMethod: 'phone', notes: '',
  });
  const state = {
    draft: newDraft(), step: 1, config: null, loading: true, errors: {}, notice: '',
    saved: null, secrets: null, submitting: false, retryPayload: null,
    cancelCode: '', cancelBusy: false, historyNotice: '', history: [],
  };
  if (!offline) {
    try {
      state.history = JSON.parse(sessionStorage.getItem(historyKey) || '[]').filter(item =>
        /^RASH-\d{8}-[A-F0-9]{6}$/.test(item.orderCode) && /^[a-f0-9]{64}$/.test(item.cancellationToken));
    } catch { /* The cart works when storage is restricted. */ }
  }
  const delivery = () => state.config?.settings.delivery || [];
  const label = (item) => lang() === 'ar' ? item.name : places[item.id] || item.name;
  const kindName = (type, kind) => products[type][kind][lang()];
  const textPrice = (price) => price === 0 ? t('free') : moneyText(price);
  const formattedPrice = (price) => price === 0 ? t('free') : money(price);
  const fieldError = (name) => state.errors[name] ? t(state.errors[name]) : '';
  const friendlyName = (item, index) => t('unit', { product: kindName('personal', item.kind), number: index + 1 });
  const goButton = (key, action, primary = true) =>
    `<button type="button" class="button ${primary ? 'button-primary' : 'button-outline'}" data-action="${action}">${t(key)}${primary ? icon('arrow') : ''}</button>`;
  const retryBlock = () => `<p class="form-error" role="alert">${t('loadError')}</p>
    <button type="button" class="button button-outline" data-action="retry-config">${t('retry')}</button>`;
  const privacyLink = () => `<a href="${offline ? '#privacy' : '/privacy'}" data-privacy>${t('privacy')}</a>`;

  async function rpc(method, input) {
    const query = '?batch=1&input=%7B%220%22%3A%7B%22json%22%3Anull%2C%22meta%22%3A%7B%22values%22%3A%5B%22undefined%22%5D%2C%22v%22%3A1%7D%7D%7D';
    const url = '/api/trpc/' + method + (input ? '?batch=1' : query);
    const options = { signal: AbortSignal.timeout(10000), credentials: 'same-origin' };
    if (input) Object.assign(options, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ 0: { json: input } }),
    });
    const response = await fetch(url, options);
    const [envelope] = await response.json();
    if (!response.ok || !envelope.result) {
      const error = new Error('Request failed');
      error.status = response.status;
      error.fields = envelope.error?.json?.data?.fields;
      throw error;
    }
    return envelope.result.data.json;
  }

  async function loadConfig() {
    state.loading = true;
    renderDelivery();
    renderCheckout();
    try {
      const config = offline ? globalThis.RashOfflineConfig : await rpc('site.publicConfig');
      if (!Array.isArray(config?.settings?.delivery) || !config.settings.delivery.length) throw new Error('Missing delivery');
      state.config = config;
    } catch {
      state.config = null;
    }
    state.loading = false;
    renderDelivery();
    renderCheckout();
    renderContacts();
    renderSummary();
  }

  function renderCatalog() {
    const catalog = $('catalog');
    if (catalog.dataset.lang !== lang()) {
      catalog.innerHTML = catalogMarkup(lang(), assets, !offline);
      catalog.dataset.lang = lang();
    }
  }

  function deliveryFields(prefix, detailed) {
    const { governorateId, areaId } = state.draft;
    const { governorate, area } = lookup(delivery(), governorateId, areaId);
    const choices = delivery().map(item => `<option value="${esc(item.id)}"${item.id === governorateId ? ' selected' : ''}>${esc(label(item))}</option>`);
    const errorAttrs = (key) => detailed ? `aria-describedby="${prefix}-${key}-error" aria-invalid="${Boolean(fieldError(key))}"` : '';
    const errorText = (key) => detailed ? `<span class="field-error" id="${prefix}-${key}-error">${fieldError(key)}</span>` : '';
    const areaOptions = governorate?.areas.map(item => `<option value="${esc(item.id)}"${item.id === areaId ? ' selected' : ''}>${esc(label(item))}</option>`);
    return `<div class="field">
        <label for="${prefix}-governorate">${t('governorate')}</label>
        <select id="${prefix}-governorate" data-location="governorateId" ${errorAttrs('governorateId')}>
          <option value="">${t('chooseGovernorate')}</option>${choices.join('')}
        </select>${errorText('governorateId')}
      </div>
      ${governorate && (detailed || governorate.areas.length > 1) ? `<div class="field">
        <label for="${prefix}-area">${t('area')}</label>
        <select id="${prefix}-area" data-location="areaId" ${errorAttrs('areaId')}>${areaOptions.join('')}</select>${errorText('areaId')}
      </div>` : ''}
      <p class="delivery-output quiet" role="status">${area ? `${t(detailed ? 'deliveryFee' : 'rateTitle')} · ${formattedPrice(detailed ? calculate(state.draft, delivery()).deliveryFee : area.feeFils)}` : t('deliveryPrompt')}</p>`;
  }

  function renderDelivery() {
    const card = $('delivery-card');
    card.setAttribute('aria-busy', String(state.loading));
    if (state.loading || !state.config) {
      card.innerHTML = state.loading ? `<div class="skeleton" aria-hidden="true"></div><p role="status">${t('loading')}</p>` : retryBlock();
      $('delivery-cities').textContent = '';
      return;
    }
    $('delivery-cities').innerHTML = `<ul class="city-list" aria-label="${t('covered')}">${delivery().map(item => `<li>${esc(label(item))}</li>`).join('')}</ul>`;
    const amman = lookup(delivery(), 'amman', 'customer-location').area;
    const zarqa = lookup(delivery(), 'zarqa', 'customer-location').area;
    const university = lookup(delivery(), 'amman', 'amman-arab-university').area;
    const remaining = delivery().filter(item => !['amman', 'zarqa'].includes(item.id));
    const otherRates = new Set(remaining.map(item => item.areas.find(area => area.id === 'customer-location')?.feeFils));
    const grouped = amman && zarqa && amman.feeFils === zarqa.feeFils && university && otherRates.size === 1 && !otherRates.has(undefined);
    const rates = grouped ? `<dl class="rate-list">
      <div><dt>${t('ammanZarqa')}</dt><dd>${formattedPrice(amman.feeFils)}</dd></div>
      <div><dt>${t('otherAreas')}</dt><dd>${formattedPrice([...otherRates][0])}</dd></div>
      <div><dt>${t('university')}</dt><dd>${formattedPrice(university.feeFils)}</dd></div>
    </dl>` : '';
    card.innerHTML = `<h3 class="panel-heading">${icon('pin')}${t('rateTitle')}</h3>${rates}
      ${deliveryFields('estimate', false)}
      <p class="quiet">${t('thresholdPolicy', { personal: money(thresholds.personal), supermarket: money(thresholds.supermarket) })}</p>`;
  }

  function renderContacts() {
    const contact = state.config?.settings.contacts;
    $('contacts').innerHTML = contact?.confirmed && normalizePhone(contact.whatsapp)
      ? `<a class="button button-outline support" href="https://wa.me/${normalizePhone(contact.whatsapp).slice(1)}" target="_blank" rel="noopener noreferrer">
        ${icon('chat')}<span>${t('support')}</span><bdi dir="ltr">0${normalizePhone(contact.whatsapp).slice(4)}</bdi></a>`
      : `<span class="quiet">${t('contactSoon')}</span>`;
  }

  function totalsMarkup(order, includeHint = true) {
    const total = calculate(order, delivery());
    return `<dl class="totals">
      <div><dt>${t('subtotal')}</dt><dd>${money(total.subtotal)}</dd></div>
      <div><dt>${t('deliveryFee')}</dt><dd>${total.deliveryFee === null ? t('unavailable') : formattedPrice(total.deliveryFee)}</dd></div>
      <div><dt>${t('total')}</dt><dd>${total.total === null ? '—' : money(total.total)}</dd></div>
    </dl>${total.total === null && includeHint ? `<p class="quiet">${t('selectToTotal')}</p>` : ''}`;
  }

  function itemsMarkup(order) {
    const type = order.orderType;
    const items = type === 'personal' ? order.personalItems.map((item, index) => {
      const text = item.flavors.map(flavor => lang() === 'ar' ? flavor : flavors[flavor]).join(lang() === 'ar' ? '، ' : ', ');
      return `<li><span>${friendlyName(item, index)}<small>${esc(text)}</small></span>${money(products.personal[item.kind].price)}</li>`;
    }) : kinds.filter(kind => order.supermarketItems[kind] > 0).map(kind =>
      `<li><span>${kindName(type, kind)} <bdi>×${order.supermarketItems[kind]}</bdi></span>${money(order.supermarketItems[kind] * products[type][kind].price)}</li>`);
    return items.length ? `<ul class="summary-list">${items.join('')}</ul>` : `<p class="quiet">${t('emptySummary')}</p>`;
  }

  function renderSummary() {
    const order = state.draft;
    const count = order.orderType === 'personal' ? order.personalItems.length : order.supermarketItems.cup + order.supermarketItems.plate;
    $('cart-count').hidden = !count;
    $('cart-count').textContent = count;
    $('summary-content').innerHTML = `${itemsMarkup(order)}${totalsMarkup(order)}<p id="summary-note" class="summary-note quiet"></p>`;
    renderSummaryNote();
  }

  function renderSummaryNote() {
    const note = $('summary-note');
    const value = state.draft.notes.trim();
    note.hidden = !value;
    note.textContent = value ? t('notes') + '\n' + value : '';
  }

  function productStep() {
    const { orderType, personalItems, supermarketItems } = state.draft;
    const options = types.map(type => `<button type="button" class="type-choice" data-action="type" data-type="${type}" aria-pressed="${orderType === type}">
      ${icon(orderType === type ? 'check' : type === 'personal' ? 'gift' : 'box')}
      <strong>${t(type)}</strong><small>${t(type + 'Hint')}</small></button>`);
    const buttons = kinds.map(kind => {
      const product = products[orderType][kind];
      const name = product[lang()];
      return `<div class="mini-product"><h4>${name}</h4><p>${tr(product.detail)}</p>
      <b class="product-price">${money(product.price)}</b>${orderType === 'personal'
        ? `<button type="button" class="button button-soft" data-action="add" data-kind="${kind}"${personalItems.length >= limits.personal ? ' disabled' : ''}>${icon('plus')}${t('addPersonal', { product: name })}</button>`
        : `<div class="quantity" role="group" aria-label="${esc(name)}">
          <button type="button" class="control" data-action="down" data-kind="${kind}" aria-label="${esc(t('decrease', { product: name }))}"${!supermarketItems[kind] ? ' disabled' : ''}>${icon('minus')}</button>
          <b>${supermarketItems[kind]}</b>
          <button type="button" class="control" data-action="up" data-kind="${kind}" aria-label="${esc(t('increase', { product: name }))}"${supermarketItems[kind] >= limits.supermarket ? ' disabled' : ''}>${icon('plus')}</button></div>`}</div>`;
    });
    const units = personalItems.map((item, index) => {
      const name = friendlyName(item, index);
      const chips = Object.entries(flavors).map(([id, en]) => {
        const picked = item.flavors.includes(id);
        return `<button type="button" class="flavor" data-action="flavor" data-unit="${item.id}" data-flavor="${esc(id)}" aria-pressed="${picked}">
          ${picked ? icon('check') : ''}${lang() === 'ar' ? id : en}</button>`;
      });
      return `<section class="unit-card" aria-labelledby="title-${item.id}">
        <div class="unit-head"><div><h4 id="title-${item.id}">${name}</h4><small>${money(products.personal[item.kind].price)}</small></div>
          <button type="button" class="remove" data-action="remove" data-unit="${item.id}" aria-label="${esc(t('removeUnit', { unit: name }))}">${t('remove')}</button></div>
        <div class="flavors">${chips.join('')}</div>
      </section>`;
    });
    return `<h3 tabindex="-1" id="step-title">${t('typeTitle')}</h3><div class="type-grid">${options.join('')}</div>
      <div class="mini-grid">${buttons.join('')}</div>
      ${orderType === 'personal' ? (units.length ? `<p class="quiet">${t('flavorInstructions')}</p><div class="unit-list">${units.join('')}</div>`
        : `<p class="empty-box">${t('emptyPersonal')}</p>`) : ''}
      <p class="form-error" role="alert">${fieldError('items')}</p>
      <div class="step-actions">${goButton('continue', 'next')}</div>`;
  }

  function renderField(id, key, input, hint = '') {
    return `<div class="field ${id === 'deliveryAddress' ? 'field-wide' : ''}">
      <label for="${id}">${t(key)}</label>${input}
      ${hint ? `<small id="${id}-hint">${hint}</small>` : ''}
      <span class="field-error" id="${id}-error">${fieldError(id)}</span>
    </div>`;
  }

  function deliveryStep() {
    const { customerName, phone, deliveryAddress, contactMethod } = state.draft;
    return `<h3 tabindex="-1" id="step-title">${t('stepDelivery')}</h3><div class="fields">
      ${deliveryFields('order', true)}
      ${renderField('deliveryAddress', 'address', `<textarea id="deliveryAddress" data-field rows="2" maxlength="500" dir="auto" autocomplete="street-address"
        aria-describedby="deliveryAddress-hint deliveryAddress-error" aria-invalid="${Boolean(fieldError('deliveryAddress'))}">${esc(deliveryAddress)}</textarea>`, t('addressHint'))}
      ${renderField('customerName', 'name', `<input id="customerName" data-field value="${esc(customerName)}" maxlength="80" dir="auto" autocomplete="name"
        aria-describedby="customerName-error" aria-invalid="${Boolean(fieldError('customerName'))}">`)}
      ${renderField('phone', 'phone', `<input id="phone" data-field value="${esc(phone)}" type="tel" maxlength="48" dir="ltr" autocomplete="tel"
        aria-describedby="phone-hint phone-error" aria-invalid="${Boolean(fieldError('phone'))}">`, t('phoneHint'))}</div>
      <fieldset class="contact-group"><legend>${t('contact')}</legend><div class="radio-row">${contactMethods.map(value =>
        `<label><input type="radio" name="contactMethod" value="${value}"${contactMethod === value ? ' checked' : ''}>${t('contact_' + value)}</label>`).join('')}</div>
        <span class="field-error">${fieldError('contactMethod')}</span></fieldset>
      <div class="step-actions">${goButton('back', 'back', false)}${goButton('review', 'next')}</div>`;
  }

  function reviewStep() {
    const order = state.draft;
    const { governorate, area } = lookup(delivery(), order.governorateId, order.areaId);
    const locked = state.submitting || Boolean(state.retryPayload);
    const deliveryAddress = [area?.id === 'amman-arab-university' ? label(area) : '', order.deliveryAddress].filter(Boolean).join(' · ');
    const fields = [
      ['name', `<bdi>${esc(order.customerName)}</bdi>`], ['phone', `<bdi dir="ltr">${esc(normalizePhone(order.phone) || order.phone)}</bdi>`],
      ['governorate', esc(governorate ? label(governorate) : '')], ['address', `<bdi>${esc(deliveryAddress)}</bdi>`],
      ['contact', t('contact_' + order.contactMethod)],
    ];
    return `<h3 tabindex="-1" id="step-title">${t('stepReview')}</h3>
      <div class="review-mobile">${itemsMarkup(order)}${totalsMarkup(order, false)}</div>
      <dl class="review-fields">${fields.map(([key, value]) => `<div><dt>${t(key)}</dt><dd>${value}</dd></div>`).join('')}</dl>
      ${renderField('notes', 'notes', `<textarea id="notes" data-field rows="2" maxlength="${limits.notes}" dir="auto" placeholder="${esc(t('notesPlaceholder'))}"
        aria-describedby="notes-hint notes-error" ${locked ? ' readonly' : ''}>${esc(order.notes)}</textarea>`, t('notesHint'))}
      <p class="quiet" id="note-count">${order.notes.length} / ${limits.notes}</p>
      <p class="form-error" role="alert">${state.notice ? t(state.notice) : ''}</p>
      <div class="step-actions">${locked ? '' : goButton('back', 'back', false)}
        ${state.notice === 'conflict' ? goButton('newOrder', 'new')
          : `<button class="button button-primary" type="submit" ${state.submitting ? 'disabled' : ''}>${t(state.submitting ? 'saving' : state.retryPayload ? 'retry' : offline ? 'previewSubmit' : 'submit')}${icon('arrow')}</button>`}</div>
      <div class="privacy-near">${icon('shield')}<p>${t('privacyNear')} ${privacyLink()}</p></div>`;
  }

  function completedMarkup() {
    const saved = state.saved;
    if (offline) return `<span class="success-icon">${icon('check')}</span><h3 tabindex="-1" id="step-title">${t('offlineDone')}</h3>
      <p>${t('offlineDetail')}</p><div class="step-actions">${goButton('newOrder', 'new')}</div>`;
    const total = calculate(state.draft, delivery());
    const order = state.draft;
    const quantities = kinds.map(kind => order.orderType === 'personal' ? order.personalItems.filter(item => item.kind === kind).length : order.supermarketItems[kind]);
    const items = kinds.map((kind, index) => quantities[index] ? `${quantities[index]} × ${kindName(order.orderType, kind)}` : '').filter(Boolean).join(' · ');
    const message = [t('confirmationIntro'), `${t('orderCode')} ${saved.orderCode}`, t(order.orderType), items,
      `${t('subtotal')} ${moneyText(total.subtotal)}`, `${t('deliveryFee')} ${textPrice(total.deliveryFee)}`, `${t('total')} ${moneyText(total.total)}`].join('\n');
    return `<span class="success-icon">${icon('check')}</span><h3 tabindex="-1" id="step-title">${t('testSaved')}</h3>
      <bdi class="order-code">${esc(saved.orderCode)}</bdi><p>${t('testPending')}</p><p class="quiet">${t('savedFlow')}</p>
      <details><summary class="text-link">${t('confirmationExample')}</summary><pre class="confirmation-text">${esc(message)}</pre></details>
      <div class="step-actions">${goButton('newOrder', 'new')}</div>`;
  }

  function renderCheckout() {
    $('checkout-content').setAttribute('aria-busy', String(state.loading || state.submitting));
    $('checkout-progress').innerHTML = !state.config ? '' : `<ol class="step-list">${['stepProducts', 'stepDelivery', 'stepReview'].map((key, index) =>
      `<li${state.step === index + 1 ? ' aria-current="step"' : ''}><span class="step-number">${state.step > index + 1 ? icon('check') : index + 1}</span>${t(key)}</li>`).join('')}</ol>`;
    $('checkout-content').innerHTML = state.loading ? `<div class="skeleton" aria-hidden="true"></div><p role="status">${t('loading')}</p>`
      : !state.config ? retryBlock()
      : state.saved ? completedMarkup()
      : state.step === 1 ? productStep() : state.step === 2 ? deliveryStep() : reviewStep();
  }

  function renderHistory() {
    const target = $('order-history');
    target.hidden = !state.history.length && !state.historyNotice;
    target.innerHTML = `${state.history.length ? `<h4>${t('savedInSession')}</h4>` : ''}
      <p class="quiet" role="status">${state.historyNotice ? esc(t(state.historyNotice.key, { code: state.historyNotice.code })) : ''}</p>
      ${state.history.map(({ orderCode }) => `<div class="history-row"><bdi class="order-code">${esc(orderCode)}</bdi>
        ${state.cancelCode === orderCode
          ? `<span>${esc(t('cancelQuestion', { code: orderCode }))}</span><button class="button button-outline" type="button" data-action="cancel-confirm" data-code="${orderCode}"${state.cancelBusy ? ' disabled' : ''}>${t('cancelConfirm')}</button>
            <button class="control" type="button" data-action="cancel-back"${state.cancelBusy ? ' disabled' : ''}>${t('back')}</button>`
          : `<button class="button button-outline" type="button" data-action="cancel-open" data-code="${orderCode}">${t('cancel')}</button>`}</div>`).join('')}`;
  }

  function storeHistory() {
    try { sessionStorage.setItem(historyKey, JSON.stringify(state.history)); } catch { /* The current tab still has the cancellation token. */ }
  }

  function renderLanguage() {
    localize();
    document.title = 'Rash Candy Jo | ' + t('heroFirst') + ' ' + t('heroSecond');
    $('policy-content').innerHTML = policyMarkup();
    $('policy-content').querySelector('h1').id = 'dialog-title';
    renderCatalog();
    renderDelivery();
    renderCheckout();
    renderSummary();
    renderContacts();
    renderHistory();
  }

  function reset() {
    Object.assign(state, { draft: newDraft(), step: 1, errors: {}, notice: '', saved: null, secrets: null, retryPayload: null });
    renderDelivery();
    renderCheckout();
    renderSummary();
  }

  function add(type, kind) {
    if (state.submitting || state.retryPayload) return;
    if (state.saved) reset();
    const draft = state.draft;
    const different = draft.orderType !== type;
    draft.orderType = type;
    if (different) state.step = 1;
    let added = false;
    if (type === 'personal' && draft.personalItems.length < limits.personal) {
      draft.personalItems.push({ kind, id: crypto.randomUUID(), flavors: [] });
      added = true;
    }
    if (type === 'supermarket' && draft.supermarketItems[kind] < limits.supermarket) {
      draft.supermarketItems[kind] += 1;
      added = true;
    }
    $('catalog-notice').textContent = added ? t('added', { product: kindName(type, kind) }) : t('limitReached');
    state.errors = {};
    renderCheckout();
    renderSummary();
    return added;
  }

  function focusStep() {
    const title = $('step-title');
    if (title) title.focus();
  }

  function navigateStep(action) {
    const draft = state.draft;
    state.notice = '';
    state.errors = {};
    if (action === 'back') {
      state.step -= 1;
    } else {
      state.errors = state.step === 1 ? itemErrors(draft) : detailErrors(draft, delivery());
      if (!Object.keys(state.errors).length) state.step += 1;
    }
    renderCheckout();
    if (!Object.keys(state.errors).length || state.errors.items) {
      focusStep();
    } else {
      const target = $('checkout-content').querySelector('[aria-invalid="true"]');
      if (target) target.focus();
    }
  }

  async function cancelOrder(orderCode) {
    if (state.cancelBusy) return;
    const item = state.history.find(order => order.orderCode === orderCode);
    if (!item) return;
    state.cancelBusy = true;
    state.historyNotice = '';
    renderHistory();
    try {
      await rpc('orders.cancel', item);
      state.history = state.history.filter(order => order.orderCode !== orderCode);
      storeHistory();
      state.historyNotice = { key: 'cancelledNotice', code: orderCode };
      if (state.saved?.orderCode === orderCode) reset();
      state.cancelCode = '';
    } catch {
      state.historyNotice = { key: 'cancelError' };
    } finally {
      state.cancelBusy = false;
      renderHistory();
    }
  }

  document.addEventListener('click', event => {
    const policy = event.target.closest('[data-privacy]');
    if (policy && !event.ctrlKey && !event.metaKey && !event.shiftKey && !event.altKey && typeof $('privacy-dialog').showModal === 'function') {
      event.preventDefault();
      $('privacy-dialog').showModal();
      return;
    }
    if (event.target.closest('[data-close-dialog]')) $('privacy-dialog').close();
    const control = event.target.closest('[data-action]');
    if (!control) return;
    const { action, type, kind, unit, flavor, code } = control.dataset;
    const draft = state.draft;
    if (action === 'retry-config') { void loadConfig(); return; }
    if (action === 'cancel-open') { state.cancelCode = code; renderHistory(); $('order-history').querySelector('[data-action="cancel-confirm"]')?.focus(); return; }
    if (action === 'cancel-back') { state.cancelCode = ''; renderHistory(); $('order-history').querySelector('[data-action="cancel-open"]')?.focus(); return; }
    if (action === 'cancel-confirm') { void cancelOrder(code); return; }
    if (state.submitting || state.retryPayload) return;
    if (action === 'catalog-add') {
      if (!add(type, kind)) return;
      control.dataset.added = 'true';
      control.innerHTML = icon('check') + t('add');
      return;
    }
    if (action === 'new') { reset(); focusStep(); return; }
    if (action === 'next' || action === 'back') { navigateStep(action); return; }
    if (action === 'add' || action === 'up') {
      add(draft.orderType, kind);
    } else {
      if (action === 'type') draft.orderType = type;
      if (action === 'down') draft.supermarketItems[kind] -= 1;
      if (action === 'remove') draft.personalItems = draft.personalItems.filter(item => item.id !== unit);
      if (action === 'flavor') {
        const item = draft.personalItems.find(row => row.id === unit);
        item.flavors = item.flavors.includes(flavor) ? item.flavors.filter(value => value !== flavor) : [...item.flavors, flavor];
      }
      state.errors = {};
      renderCheckout();
      renderSummary();
    }
    const attributes = [['action', action], ['type', type], ['kind', kind], ['unit', unit], ['flavor', flavor]];
    const selector = attributes.filter(([, value]) => value).map(([key, value]) => `[data-${key}="${CSS.escape(value)}"]`).join('');
    const replacement = $('checkout-content').querySelector(selector);
    if (replacement && !replacement.disabled) replacement.focus({ preventScroll: true });
    else if (action === 'remove') $('checkout-content').querySelector('[data-action="add"]')?.focus({ preventScroll: true });
  });

  document.addEventListener('change', event => {
    const field = event.target;
    if (field.name === 'contactMethod') state.draft.contactMethod = field.value;
    const locationField = field.dataset.location;
    if (!locationField) return;
    if (state.submitting || state.retryPayload || state.saved) {
      renderDelivery();
      return;
    }
    state.draft[locationField] = field.value;
    if (locationField === 'governorateId') state.draft.areaId = delivery().find(row => row.id === field.value)?.areas[0]?.id || '';
    delete state.errors[locationField];
    renderDelivery();
    renderCheckout();
    renderSummary();
    $(field.id)?.focus({ preventScroll: true });
  });

  $('checkout-form').addEventListener('input', event => {
    const field = event.target;
    if (!field.matches('[data-field]')) return;
    state.draft[field.id] = field.value;
    if (field.id === 'notes') {
      $('note-count').textContent = field.value.length + ' / ' + limits.notes;
      renderSummaryNote();
    }
    if (state.errors[field.id]) {
      delete state.errors[field.id];
      field.setAttribute('aria-invalid', 'false');
      $(field.id + '-error').textContent = '';
    }
  });

  $('checkout-form').addEventListener('submit', async event => {
    event.preventDefault();
    if (state.step !== 3 || state.submitting || state.saved || !state.config) return;
    const draft = state.draft;
    state.errors = { ...itemErrors(draft), ...detailErrors(draft, delivery()) };
    if (Object.keys(state.errors).length) {
      state.step = state.errors.items ? 1 : state.errors.notes ? 3 : 2;
      renderCheckout();
      focusStep();
      return;
    }
    if (offline) {
      state.saved = {};
      renderCheckout();
      focusStep();
      return;
    }
    state.secrets ??= secrets();
    const payload = state.retryPayload || {
      ...state.secrets, orderType: draft.orderType, customerName: draft.customerName.trim(),
      phone: normalizePhone(draft.phone), governorateId: draft.governorateId, areaId: draft.areaId,
      deliveryAddress: draft.deliveryAddress.trim(), contactMethod: draft.contactMethod, notes: draft.notes.trim(),
      ...(draft.orderType === 'personal'
        ? { personalItems: draft.personalItems.map(({ kind, flavors }) => ({ kind, flavors })) }
        : { supermarketItems: { ...draft.supermarketItems } }),
    };
    state.retryPayload = payload;
    state.submitting = true;
    state.notice = '';
    renderCheckout();
    try {
      const result = await rpc('orders.create', payload);
      if (!/^RASH-\d{8}-[A-F0-9]{6}$/.test(result.orderCode)) throw new Error('Unverified order code');
      state.saved = result;
      state.retryPayload = null;
      state.history.unshift({ orderCode: result.orderCode, cancellationToken: payload.cancellationToken });
      storeHistory();
      renderHistory();
    } catch (error) {
      if (error.status === 409) {
        state.retryPayload = null;
        state.notice = 'conflict';
      } else if (error.status === 400) {
        state.retryPayload = null;
        state.errors = error.fields || {};
        state.step = state.errors.items ? 1 : Object.keys(state.errors).length && !state.errors.notes ? 2 : 3;
        state.notice = 'rejected';
      } else if (error.status === 429) {
        state.notice = 'busy';
      } else {
        state.notice = 'saveError';
      }
    } finally {
      state.submitting = false;
      renderCheckout();
      focusStep();
    }
  });

  if (offline) document.querySelectorAll('[data-home]').forEach(link => { link.href = '#main'; });
  initPreferences(renderLanguage);
  renderLanguage();
  void loadConfig();
})();
