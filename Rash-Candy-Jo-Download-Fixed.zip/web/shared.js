'use strict';

(() => {
  const copy = {
    skip: ['انتقل إلى المحتوى', 'Skip to content'],
    preview: ['نسخة معاينة · الطلبات تجريبية', 'Review preview · Test orders only'],
    country: ['من الأردن وبمحبة', 'From Jordan, with love'],
    nav: ['التنقّل الرئيسي', 'Main navigation'],
    story: ['حكايتنا', 'Our story'],
    products: ['المنتجات', 'Products'],
    delivery: ['التوصيل', 'Delivery'],
    order: ['نموذج الطلب', 'Order form'],
    orderNow: ['ابدأ طلبك', 'Start your order'],
    browse: ['شوف الخيارات', 'Explore products'],
    brandTag: ['حلوى بتفرّح القلب', 'Candy to brighten your day'],
    heroKicker: ['مذاق حلو… على ذوقك', 'A little sweetness, your way'],
    heroFirst: ['حلاوتك', 'Your sweet moment'],
    heroSecond: ['بتبلّش من هون.', 'starts here.'],
    heroBody: ['تشكيلة حلوى على ذوقك. اختار كاسة أو صحن، واعرف رسوم التوصيل قبل تأكيد الطلب.', 'A candy mix to suit your taste. Choose a cup or a plate and see your delivery fee before confirming.'],
    heroCaption: ['كاندي للأفراد والسوبرماركت', 'Candy for personal and supermarket orders'],
    heroAlt: ['تشكيلة ملوّنة من الحلوى والجيلي والمارشميلو', 'A colorful assortment of sweets, jellies and marshmallows'],
    photo: ['صور المتجر الأصلية', 'Original store photos'],
    benefit1: ['نكهات لكل وحدة', 'Flavors for each unit'],
    benefit1Detail: ['في الطلب الشخصي', 'With personal orders'],
    benefit2: ['رسوم توصيل واضحة', 'Clear delivery fees'],
    benefit2Detail: ['احسبها قبل الطلب', 'See the fee before ordering'],
    benefit3: ['التأكيد بالتواصل', 'Confirmed by the shop'],
    benefit3Detail: ['المتجر يراجع طلبك', 'After reviewing your order'],
    productsTitle: ['اختار حلاوتك.', 'Pick your sweets.'],
    productsBody: ['كاسات وصحون للطلبات الشخصية وللسوبرماركت. الأسعار بالدينار الأردني.', 'Cups and plates for personal and supermarket orders. Prices are in Jordanian dinars.'],
    personal: ['طلب شخصي', 'Personal order'],
    supermarket: ['للسوبرماركت', 'Supermarket'],
    personalHint: ['اختار نكهات كل كاسة وصحن.', 'Choose flavors for each cup and plate.'],
    supermarketHint: ['حدّد الكمية من الكاسات والصحون المشكلة.', 'Choose quantities of assorted cups and plates.'],
    add: ['أضف', 'Add'],
    addNamed: ['أضف {product}', 'Add {product}'],
    addPersonal: ['إضافة {product}', 'Add {product}'],
    added: ['تمت إضافة {product}.', '{product} added.'],
    limitReached: ['وصلت للحد الأقصى لهذا الطلب.', 'You’ve reached the quantity limit for this order.'],
    goOrder: ['تابع لنموذج الطلب', 'Go to the order form'],
    deliveryTitle: ['حلاوتك أقرب مما تتوقع.', 'Sweetness a little closer.'],
    deliveryBody: ['اختار محافظتك لتعرف الرسوم الأساسية. بتنحسب الرسوم النهائية حسب الموقع وقيمة المنتجات.', 'Choose your governorate to see the base rate. The final fee depends on the location and order subtotal.'],
    rateTitle: ['رسوم التوصيل الأساسية', 'Base delivery rates'],
    ammanZarqa: ['عمّان والزرقاء', 'Amman and Zarqa'],
    otherAreas: ['باقي المحافظات المدرجة', 'Other listed governorates'],
    university: ['جامعة عمّان العربية', 'Amman Arab University'],
    covered: ['المحافظات المتاحة', 'Available governorates'],
    chooseGovernorate: ['اختار المحافظة.', 'Choose a governorate.'],
    chooseArea: ['اختار موقع التوصيل.', 'Choose a delivery location.'],
    deliveryPrompt: ['اختار محافظتك حتى تظهر رسوم التوصيل.', 'Select your governorate to see the delivery fee.'],
    free: ['مجاني', 'Free'],
    thresholdPolicy: ['التوصيل مجاني من {personal} للطلب الشخصي ومن {supermarket} للسوبرماركت.', 'Delivery is free from {personal} for personal orders and from {supermarket} for supermarket orders.'],
    timing: ['موعد التجهيز والتوصيل يُنسّق مع المتجر عند التأكيد.', 'The shop will confirm preparation and delivery timing with you.'],
    orderKicker: ['كل الحلا بكم خطوة', 'A few steps to something sweet'],
    orderTitle: ['خلّينا نرتّب طلبك سوا.', 'Let’s put your order together.'],
    orderBody: ['اختار المنتجات، أضف تفاصيل التوصيل، وراجع المجموع. التأكيد بعد تواصل المتجر معك.', 'Choose your sweets, add delivery details and review the total. The shop will contact you to confirm.'],
    stepProducts: ['المنتجات', 'Products'],
    stepDelivery: ['التوصيل والتواصل', 'Delivery and contact'],
    stepReview: ['مراجعة الطلب', 'Review'],
    typeTitle: ['اختار نوع الطلب', 'Choose your order type'],
    flavorHeading: ['نكهات كل وحدة', 'Flavors for each unit'],
    flavorInstructions: ['اختار نكهة واحدة على الأقل لكل وحدة.', 'Choose at least one flavor for each unit.'],
    emptyPersonal: ['أضف كاسة أو صحن حتى تختار نكهاتها.', 'Add a cup or a plate to choose its flavors.'],
    unit: ['{product} رقم {number}', '{product} {number}'],
    remove: ['حذف', 'Remove'],
    removeUnit: ['حذف {unit}', 'Remove {unit}'],
    increase: ['زيادة عدد {product}', 'Increase {product} quantity'],
    decrease: ['تقليل عدد {product}', 'Decrease {product} quantity'],
    chooseItems: ['أضف كاسة أو صحن واحد على الأقل.', 'Add at least one cup or plate.'],
    chooseFlavors: ['اختار نكهة واحدة على الأقل لكل كاسة وصحن.', 'Choose at least one flavor for every cup and plate.'],
    invalidType: ['اختار نوع الطلب.', 'Choose an order type.'],
    name: ['الاسم الكامل', 'Full name'],
    phone: ['رقم الموبايل الأردني', 'Jordanian mobile number'],
    phoneHint: ['صيغة محلية تبدأ بـ 07 أو دولية تبدأ بـ ‎+962.', 'Use a local 07 or international +962 format.'],
    governorate: ['المحافظة', 'Governorate'],
    area: ['موقع التوصيل', 'Delivery location'],
    address: ['عنوان التوصيل بالتفصيل', 'Detailed delivery address'],
    addressHint: ['اكتب اسم الحي والشارع ورقم البناية أو أقرب معلم.', 'Include the neighborhood, street, building number or a nearby landmark.'],
    contact: ['طريقة التواصل المفضلة', 'Preferred contact method'],
    contact_phone: ['مكالمة هاتفية', 'Phone call'],
    contact_whatsapp: ['رسالة واتساب', 'WhatsApp message'],
    contact_both: ['مكالمة وواتساب', 'Call and WhatsApp'],
    chooseContact: ['اختار طريقة التواصل.', 'Choose a contact method.'],
    invalidName: ['اكتب اسماً صحيحاً من حرفين على الأقل.', 'Enter a valid name with at least two letters.'],
    invalidPhone: ['اكتب رقم موبايل أردني يبدأ بـ 077 أو 078 أو 079، أو ما يعادله بصيغة ‎+962.', 'Enter a Jordanian mobile number beginning with 077, 078 or 079, or its +962 equivalent.'],
    invalidAddress: ['اكتب عنواناً واضحاً بين 10 و500 حرف.', 'Enter a detailed address of 10 to 500 characters.'],
    invalidNotes: ['الملاحظات بحد أقصى 500 حرف.', 'Notes can be up to 500 characters.'],
    notes: ['ملاحظات الطلب (اختياري)', 'Order notes (optional)'],
    notesPlaceholder: ['مثلاً وصف إضافي لمكان التسليم', 'For example, extra directions for delivery'],
    notesHint: ['بنراجع إمكانية تنفيذ الملاحظات وقت التأكيد. الملاحظات لا تضمن خلو المنتجات من آثار مسببات الحساسية أو التلامس معها.', 'The shop will review whether it can accommodate notes at confirmation. Notes cannot guarantee that products are free from allergen traces or cross-contact.'],
    allergens: ['اسأل المتجر عن المكونات ومسببات الحساسية قبل الطلب.', 'Ask the shop about ingredients and allergens before ordering.'],
    summary: ['ملخّص طلبك', 'Your order summary'],
    emptySummary: ['اختياراتك بتظهر هون أول ما تضيفها.', 'Your picks appear here as you add them.'],
    subtotal: ['قيمة المنتجات', 'Items subtotal'],
    deliveryFee: ['رسوم التوصيل', 'Delivery fee'],
    total: ['المجموع المبدئي', 'Estimated total'],
    unavailable: ['قيد الاختيار', 'Pending selection'],
    selectToTotal: ['المجموع بيظهر بعد اختيار موقع التوصيل.', 'Select your delivery location to see the total.'],
    back: ['رجوع', 'Back'],
    continue: ['متابعة', 'Continue'],
    review: ['راجع الطلب', 'Review order'],
    submit: ['حفظ الطلب التجريبي', 'Save test order'],
    previewSubmit: ['جرّب مراجعة الطلب', 'Complete the test review'],
    privacyNear: ['يستخدم المتجر بيانات الطلب للتجهيز والتوصيل والتواصل بشأن التأكيد.', 'The shop uses order details to prepare and deliver the order and contact you about confirmation.'],
    privacy: ['سياسة الخصوصية', 'Privacy Policy'],
    loading: ['لحظة، بنجهّز خيارات التوصيل…', 'Loading delivery options…'],
    loadError: ['تعذّر تحميل خيارات التوصيل.', 'Delivery options could not be loaded.'],
    retry: ['إعادة المحاولة', 'Try again'],
    saving: ['جارٍ حفظ الطلب…', 'Saving your order…'],
    saveError: ['تعذّر التحقق من نتيجة الحفظ. أعد المحاولة بنفس التفاصيل.', 'The save result could not be verified. Retry with the same details.'],
    rejected: ['تعذّر حفظ الطلب. راجع الحقول المعلّمة.', 'The order could not be saved. Check the highlighted fields.'],
    busy: ['عدد المحاولات مرتفع. أعد المحاولة بعد قليل.', 'Too many attempts. Try again shortly.'],
    conflict: ['هذا الطلب محفوظ بتفاصيل مختلفة. ابدأ طلباً جديداً.', 'This order was already saved with different details. Start a new order.'],
    testSaved: ['انحفظ طلبك التجريبي.', 'Your test order was saved.'],
    offlineDone: ['اكتملت مراجعة الطلب التجريبي.', 'Your test review is complete.'],
    offlineDetail: ['بقيت البيانات ضمن هذه الصفحة. لتجربة الحفظ والإلغاء، شغّل نسخة المشروع على جهازك.', 'The details stayed on this page. Run the project locally to test saving and cancellation.'],
    testPending: ['بانتظار التأكيد · بيئة اختبار', 'Awaiting confirmation · Test environment'],
    savedFlow: ['في المتجر، بعد حفظ الطلب، بتفتح واتساب وترسل رسالة التأكيد بنفسك. المتجر بيراجع التفاصيل وبيتواصل معك.', 'In the store, you open WhatsApp after saving and send the confirmation message yourself. The shop reviews the details and contacts you.'],
    confirmationExample: ['عاين رسالة التأكيد', 'Preview the confirmation message'],
    confirmationIntro: ['مرحباً، أرسل لتأكيد طلبي.', 'Hello, I’m writing to confirm my order.'],
    newOrder: ['ابدأ طلباً جديداً', 'Start a new order'],
    cancel: ['إلغاء الطلب', 'Cancel order'],
    savedInSession: ['الطلبات التجريبية في هذه الجلسة', 'Test orders from this session'],
    cancelQuestion: ['تأكيد إلغاء الطلب {code}؟', 'Confirm cancellation of order {code}?'],
    cancelConfirm: ['تأكيد الإلغاء', 'Confirm cancellation'],
    cancelledNotice: ['تم إلغاء الطلب {code}.', 'Order {code} was cancelled.'],
    cancelError: ['تعذّر إلغاء الطلب. تأكّد من حالته وأعد المحاولة.', 'The order could not be cancelled. Check its status and try again.'],
    orderCode: ['رقم الطلب', 'Order number'],
    storyKicker: ['مش بس حلوى', 'More than candy'],
    storyFirst: ['اختيارك إله', 'Your pick has'],
    storySecond: ['طعم ثاني.', 'a flavor of its own.'],
    storyBody: ['كاسة أو صحن بتشكيلة نكهات مفضلة. أضف عدة وحدات وحدّد نكهات كل وحدة لحالها، والباقي بنرتّبه سوا.', 'Pick a cup or plate with your favorite mix. Add several units and choose each mix separately. We’ll arrange the rest together.'],
    storyCTA: ['يلا نبدأ', 'Let’s get started'],
    footerLine: ['حلاوتك على ذوقك، والطلب بنرتّبه سوا.', 'Sweetness your way. We’ll put your order together.'],
    support: ['واتساب الدعم الفني', 'WhatsApp support'],
    contactSoon: ['تفاصيل التواصل قريباً.', 'Contact details are coming soon.'],
    made: ['صُنع بمحبة في الأردن', 'Made with love in Jordan'],
    home: ['الرئيسية', 'Home'],
    privacyIntro: ['مسودة سياسة الخصوصية للمعاينة', 'Draft privacy policy for review'],
    privacyMode: ['هذه المسودة تصف نسخة المعاينة. تُستكمل بيانات المشغّل وجهة التواصل وسياسات الاستضافة والاحتفاظ قبل الإطلاق.', 'This draft describes the review version. Operator and contact details, hosting arrangements, and retention terms are pending before launch.'],
    privacyUpdated: ['آخر تحديث للمسودة · 6 تشرين الثاني 2026', 'Draft updated · November 6, 2026'],
    policyOperator: ['مشغّل المتجر والتواصل', 'Store operator and contact'],
    policyOperatorText: ['الاسم التجاري Rash Candy Jo. الاسم القانوني للمشغّل وجهة طلبات الخصوصية بانتظار تأكيد المالك. رابط الدعم المنشور متاح في تذييل المتجر.', 'The trading name is Rash Candy Jo. The legal operator and privacy contact are pending owner confirmation. The published support link is available in the store footer.'],
    policyData: ['بيانات الطلب واستخدامها', 'Order details and their use'],
    policyDataText: ['الاسم ورقم الموبايل وطريقة التواصل للتأكيد. المحافظة والموقع والعنوان لترتيب التسليم. المنتجات والكميات والنكهات والملاحظات لحساب الطلب وتجهيزه. تُحفظ الطلبات التجريبية في قاعدة بيانات محلية عند تشغيل الخادم. في المعاينة المستقلة، يبقى النموذج في ذاكرة الصفحة.', 'Name, mobile number and contact method support confirmation. Governorate, location and address are used for delivery. Products, quantities, flavors and optional notes are used to calculate and prepare the order. The local server stores test orders in its database. In the standalone preview, form entries stay in page memory.'],
    policyStorage: ['التفضيلات والجلسات', 'Preferences and sessions'],
    policyStorageText: ['يحفظ المتصفح اختيار اللغة والمظهر فقط في التخزين المحلي. في نسخة الخادم، يُحفظ رقم الطلب ورمز الإلغاء لهذه الجلسة في المتصفح. تستخدم بوابة المالك ملف ارتباط خاصاً للدخول. يستخدم الخادم عدادات مؤقتة لتقييد المحاولات ولا يسجّل محتوى الطلبات في سجل الطلبات التقني.', 'Browser local storage keeps language and appearance preferences. The server preview keeps the order number and cancellation capability for the tab session. The owner portal uses a dedicated sign-in cookie. The server uses temporary rate-limit counters and does not log order contents in request logs.'],
    policySharing: ['التتبع والخدمات الخارجية', 'Tracking and external services'],
    policySharingText: ['لا تتضمن المعاينة أدوات تتبع إعلاني أو بيع بيانات. عند الضغط على رابط الدعم، يفتح واتساب وتطبق سياسته الخاصة. لا تنقل معاينة الطلب تفاصيلك إلى واتساب. جهات الاستضافة والتوصيل اللازمة للإطلاق بانتظار الاعتماد.', 'The preview contains no ad tracking or data sales. Choosing the support link opens WhatsApp under its own privacy policy. The order preview does not transfer details to WhatsApp. Hosting and any delivery partners are pending approval for launch.'],
    policyRights: ['الاحتفاظ والطلبات المتعلقة بالبيانات', 'Retention and data requests'],
    policyRightsText: ['تُحفظ سجلات الاختبار محلياً وتُزال مع قاعدة الاختبار عند انتهاء المراجعة. مدد احتفاظ الطلبات والسجلات وإجراءات الحذف للإطلاق بانتظار الاعتماد. بعد اعتماد جهة الخصوصية يمكنك طلب الوصول أو التصحيح أو الحذف وفق الالتزامات المطبقة.', 'Test records are held locally and can be removed with the test database after review. Production order and log retention and deletion procedures are pending approval. Once the privacy contact is confirmed, you can request access, corrections or deletion subject to applicable obligations.'],
    close: ['إغلاق', 'Close'],
    notFound: ['الصفحة غير موجودة', 'Page not found'],
    backHome: ['العودة إلى المتجر', 'Back to the store'],
    ownerTitle: ['بوابة المالك', 'Owner portal'],
    ownerSubtitle: ['مراجعة طلبات نسخة الاختبار وإدارة حالتها.', 'Review and manage orders from the test environment.'],
    ownerLogin: ['تسجيل دخول المالك', 'Owner sign-in'],
    ownerEmail: ['بريد المالك', 'Owner email'],
    password: ['كلمة المرور', 'Password'],
    totp: ['رمز تطبيق المصادقة (عند تفعيله)', 'Authenticator code (if enabled)'],
    login: ['دخول', 'Sign in'],
    logout: ['تسجيل الخروج', 'Sign out'],
    loginError: ['تعذّر الدخول. تأكد من بيانات الدخول ورمز المصادقة.', 'Could not sign in. Check your credentials and authenticator code.'],
    setupRequired: ['بوابة الاختبار بانتظار إعداد حساب المالك على الخادم.', 'The test portal is waiting for the owner account to be set up on the server.'],
    ownerOrders: ['الطلبات التجريبية', 'Test orders'],
    ownerLoading: ['جارٍ تحميل الطلبات…', 'Loading orders…'],
    ownerEmpty: ['ما في طلبات تجريبية حتى الآن.', 'No test orders yet.'],
    ownerError: ['تعذّر تحميل الطلبات. جرّب مرة ثانية.', 'Could not load orders. Try again.'],
    orderStatus: ['حالة الطلب', 'Order status'],
    pending: ['بانتظار التأكيد', 'Pending confirmation'],
    confirmed: ['مؤكّد', 'Confirmed'],
    cancelled: ['ملغى', 'Cancelled'],
    date: ['تاريخ الطلب', 'Order date'],
    scheduled: ['الموعد المجدول', 'Scheduled time'],
    updateStatus: ['حفظ الحالة', 'Save status'],
    statusSaved: ['تم تحديث حالة الطلب.', 'Order status updated.'],
    statusError: ['تعذّر تحديث حالة الطلب. حدّث القائمة وحاول مرة ثانية.', 'Could not update the status. Refresh the list and try again.'],
    refresh: ['تحديث الطلبات', 'Refresh orders'],
    previousPage: ['الصفحة السابقة', 'Previous page'],
    nextPage: ['الصفحة التالية', 'Next page'],
  };

  const paths = {
    arrow: '<path d="M4.5 12h14m-6-6 6 6-6 6"/>',
    bag: '<path d="M5 8h14l1.5 13h-17L5 8Z"/><path d="M9 9V6a3 3 0 0 1 6 0v3"/>',
    pin: '<path d="M20 10c0 5.5-8 11-8 11S4 15.5 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.6"/>',
    sparkle: '<path d="M11 2.5c.8 5.4 2.1 6.7 7.5 7.5-5.4.8-6.7 2.1-7.5 7.5-.8-5.4-2.1-6.7-7.5-7.5 5.4-.8 6.7-2.1 7.5-7.5ZM19 14v6m-3-3h6"/>',
    check: '<path d="m4.5 12 5 5L20 6.5"/>',
    moon: '<path d="M20.5 14.3A8.5 8.5 0 0 1 9.7 3.5a8.5 8.5 0 1 0 10.8 10.8Z"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4m0-14.2-1.4 1.4M6.3 17.7l-1.4 1.4"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2 2.5 3 5.5 3 9s-1 6.5-3 9c-2-2.5-3-5.5-3-9s1-6.5 3-9Z"/>',
    plus: '<path d="M5 12h14m-7-7v14"/>',
    minus: '<path d="M5 12h14"/>',
    chat: '<path d="M21 11.7a9 9 0 0 1-13.4 7.9L3 21l1.4-4.5A9 9 0 1 1 21 11.7Z"/><path d="M8.5 8.5c.3 3.2 2.5 5.5 6 6.4l1.2-1.2"/>',
    box: '<path d="m12 3 8 4.5v9L12 21l-8-4.5v-9L12 3Z"/><path d="m4 7.5 8 4.5 8-4.5M12 12v9M8 5.3l8 4.5"/>',
    gift: '<rect x="3" y="8" width="18" height="4" rx="1"/><path d="M5 12v8h14v-8M12 8v12m0-12H8.6C4.7 8 5.7 3 8.5 4.2c1.5.6 2.6 2 3.5 3.8Zm0 0h3.4c3.9 0 2.9-5 .1-3.8-1.5.6-2.6 2-3.5 3.8Z"/>',
    shield: '<path d="M12 22c5-2 8-6.5 8-11V5l-8-3-8 3v6c0 4.5 3 9 8 11Z"/><path d="m9 12 2 2 4-4"/>',
    close: '<path d="m6 6 12 12M18 6 6 18"/>',
  };

  const lang = () => document.documentElement.lang;
  const tr = (pair, language = lang()) => pair[language === 'ar' ? 0 : 1];
  const translate = (language, key, vars = {}) => tr(copy[key] ?? [key, key], language)
    .replace(/\{(\w+)\}/g, (_, name) => String(vars[name] ?? ''));
  const t = (key, vars) => translate(lang(), key, vars);
  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, char => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]
  ));
  const icon = (name) => `<svg class="icon icon-${name}" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] ?? ''}</svg>`;
  const numbers = Object.fromEntries(['ar', 'en'].map(language => [language,
    new Intl.NumberFormat(language + '-JO', { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
  ]));
  const moneyText = (value, language = lang()) => `${numbers[language].format(value / 100)} ${language === 'ar' ? 'د.أ' : 'JOD'}`;
  const money = (value, language = lang()) => `<bdi class="money">${moneyText(value, language)}</bdi>`;

  function catalogMarkup(language, asset = name => '/assets/' + name, useSrcset = true) {
    const { products, types, kinds } = RashStore;
    const text = (key, vars) => translate(language, key, vars);
    return types.flatMap(type => kinds.map(kind => {
      const product = products[type][kind];
      const responsive = product.small && useSrcset
        ? `srcset="${asset(product.small)} 260w, ${asset(product.image)} 520w" sizes="(max-width: 720px) 44vw, (max-width: 1270px) 22vw, 270px"` : '';
      return `<article class="product">
        <div class="product-image"><img data-product-image="${product.image}" src="${asset(product.image)}" ${responsive}
          width="${product.width}" height="${product.height}" loading="lazy" decoding="async" alt="${esc(tr(product.alt, language))}"></div>
        <div class="product-body">
          <span class="category ${type === 'supermarket' ? 'retail' : ''}">${text(type)}</span>
          <h3>${product[language]}</h3><p>${tr(product.detail, language)}</p>
          <div class="product-bottom"><strong class="product-price">${money(product.price, language)}</strong>
            <button type="button" class="button button-soft" data-action="catalog-add" data-type="${type}" data-kind="${kind}"
              aria-label="${esc(text('addNamed', { product: product[language] }) + ' · ' + text(type))}">${icon('plus')}${text('add')}</button>
          </div>
        </div>
      </article>`;
    })).join('');
  }

  const localize = () => {
    document.querySelectorAll('[data-i]').forEach(element => { element.textContent = t(element.dataset.i); });
    document.querySelectorAll('[data-i-alt]').forEach(element => { element.alt = t(element.dataset.iAlt); });
    document.querySelectorAll('[data-i-label]').forEach(element => { element.setAttribute('aria-label', t(element.dataset.iLabel)); });
    document.querySelectorAll('[data-icon]').forEach(element => { element.innerHTML = icon(element.dataset.icon); });
  };
  function updateControls() {
    const theme = document.documentElement.dataset.theme;
    const themeLabel = theme === 'dark' ? ['تفعيل الوضع الفاتح', 'Switch to light mode'] : ['تفعيل الوضع الداكن', 'Switch to dark mode'];
    document.querySelectorAll('[data-theme-toggle]').forEach(button => {
      button.innerHTML = icon(theme === 'dark' ? 'sun' : 'moon');
      button.setAttribute('aria-label', tr(themeLabel));
      button.title = tr(themeLabel);
    });
    document.querySelectorAll('[data-language-toggle]').forEach(button => {
      const nextLabel = lang() === 'ar' ? 'English' : 'العربية';
      button.innerHTML = `${icon('globe')}<span lang="${lang() === 'ar' ? 'en' : 'ar'}">${nextLabel}</span>`;
      button.setAttribute('aria-label', nextLabel);
    });
  }
  function initPreferences(onChange) {
    updateControls();
    document.addEventListener('click', event => {
      if (event.target.closest('[data-theme-toggle]')) {
        RashPrefs.set('theme', document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
        updateControls();
      }
      if (event.target.closest('[data-language-toggle]')) {
        RashPrefs.set('language', lang() === 'ar' ? 'en' : 'ar');
        onChange();
        updateControls();
      }
    });
    document.addEventListener('rash-theme', updateControls);
  }

  const policyMarkup = () => `<p class="eyebrow">${t('privacyIntro')}</p><h1>${t('privacy')}</h1>
    <p class="text-lead">${t('privacyMode')}</p><p class="quiet">${t('privacyUpdated')}</p>
    ${[['policyOperator', 'policyOperatorText'], ['policyData', 'policyDataText'], ['policyStorage', 'policyStorageText'],
      ['policySharing', 'policySharingText'], ['policyRights', 'policyRightsText']].map(([heading, body]) =>
      `<section><h2>${t(heading)}</h2><p>${t(body)}</p></section>`).join('')}`;
  globalThis.RashUI = { lang, tr, t, esc, icon, moneyText, money, localize, initPreferences, policyMarkup, catalogMarkup };
})();
