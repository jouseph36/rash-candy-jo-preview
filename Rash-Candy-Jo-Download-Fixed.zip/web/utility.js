'use strict';

(() => {
  const { t, localize, initPreferences, policyMarkup } = RashUI;
  function render() {
    localize();
    const policy = document.getElementById('policy-page');
    if (policy) policy.innerHTML = policyMarkup();
    document.title = 'Rash Candy Jo | ' + t(policy ? 'privacy' : 'notFound');
  }
  initPreferences(render);
  render();
})();
