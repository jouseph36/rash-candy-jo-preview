'use strict';

(() => {
  const products = {
    personal: {
      cup: {
        ar: 'كاسة', en: 'Cup', detail: ['أكثر من ربع كيلو', 'Over ¼ kg'], price: 200,
        image: 'personal-cup-520.webp', small: 'personal-cup-260.webp', width: 1024, height: 1536,
        source: '1000260471_9016a421.png',
        alt: ['كاسة شفافة مليئة بتشكيلة حلوى ملونة', 'Clear cup filled with assorted colorful candy'],
      },
      plate: {
        ar: 'صحن', en: 'Plate', detail: ['أكثر من نصف كيلو', 'Over ½ kg'], price: 400,
        image: 'personal-plate.webp', width: 1199, height: 1312,
        source: '1000260477_16658e9b.png',
        alt: ['صحن شفاف مقسم يحتوي تشكيلة من الحلوى الملونة', 'Clear divided plate filled with assorted colorful candy'],
      },
    },
    supermarket: {
      cup: {
        ar: 'كاسة كاندي', en: 'Candy cup', detail: ['كاسة حلوى مشكلة', 'Cup of assorted candy'], price: 75,
        image: 'supermarket-cup_78b710bd.webp', width: 800, height: 1067,
        source: 'supermarket-cup_78b710bd.webp',
        alt: ['كاسة كاندي ملونة من Rash Candy', 'Colorful Rash Candy cup'],
      },
      plate: {
        ar: 'صحن كاندي', en: 'Candy plate', detail: ['36 حبة', '36 pieces'], price: 300,
        image: 'supermarket-plate_ffa830c8.webp', width: 800, height: 1067,
        source: 'supermarket-plate_ffa830c8.webp',
        alt: ['صحن يحتوي على 36 حبة كاندي مشكلة', 'Plate with 36 pieces of assorted candy'],
      },
    },
  };

  // The Arabic flavor strings and location IDs are part of the original order contract.
  const flavors = {
    جيلي: 'Jelly',
    مارشميلو: 'Marshmallow',
    شوكولاتة: 'Chocolate',
    علكة: 'Chewing gum',
    حلقوم: 'Turkish delight',
    'سكاكر ملونة': 'Colored sweets',
    لوليبوب: 'Lollipop',
    كراميل: 'Caramel',
  };
  const places = {
    amman: 'Amman', zarqa: 'Zarqa', irbid: 'Irbid', mafraq: 'Mafraq',
    ajloun: 'Ajloun', jerash: 'Jerash', balqa: 'Balqa', madaba: 'Madaba',
    karak: 'Karak', tafilah: 'Tafilah', maan: 'Ma’an', aqaba: 'Aqaba',
    'customer-location': 'Customer-specified location',
    'amman-arab-university': 'Amman Arab University',
  };
  const thresholds = { personal: 1000, supermarket: 3000 };
  const limits = { personal: 30, supermarket: 99, notes: 500 };
  const types = ['personal', 'supermarket'];
  const kinds = ['cup', 'plate'];
  const statuses = ['pending', 'confirmed', 'cancelled'];
  const contactMethods = ['phone', 'whatsapp', 'both'];

  function normalizePhone(value) {
    if (typeof value !== 'string' || value.length > 48) return null;
    const digits = value
      .replace(/[٠-٩]/g, character => String(character.charCodeAt(0) - 0x660))
      .replace(/[۰-۹]/g, character => String(character.charCodeAt(0) - 0x6f0))
      .replace(/[\s()\-‐‑‒–]/g, '');
    // Match the published checkout's accepted ranges until the owner approves a change.
    const number = /^(?:\+962|00962|0)?(7[789]\d{7})$/.exec(digits);
    return number ? '+962' + number[1] : null;
  }

  function lookup(delivery, governorateId, areaId) {
    const governorate = delivery.find(item => item.id === governorateId);
    return { governorate, area: governorate?.areas.find(item => item.id === areaId) };
  }

  function calculate(order, delivery) {
    const { orderType, personalItems, supermarketItems, governorateId, areaId } = order;
    if (!types.includes(orderType)) return { subtotal: 0, deliveryFee: null, total: null };
    const subtotal = orderType === 'personal'
      ? personalItems.reduce((sum, item) => sum + products.personal[item.kind].price, 0)
      : kinds.reduce((sum, kind) => sum + supermarketItems[kind] * products.supermarket[kind].price, 0);
    const { area } = lookup(delivery, governorateId, areaId);
    const deliveryFee = area ? (subtotal >= thresholds[orderType] ? 0 : area.feeFils) : null;
    return { subtotal, deliveryFee, total: deliveryFee === null ? null : subtotal + deliveryFee };
  }

  function itemErrors(order) {
    if (!types.includes(order.orderType)) return { items: 'invalidType' };
    if (order.orderType === 'personal') {
      const items = order.personalItems;
      if (!Array.isArray(items) || !items.length || items.length > limits.personal) return { items: 'chooseItems' };
      for (const item of items) {
        if (!item || !kinds.includes(item.kind)) return { items: 'chooseItems' };
        const selected = item.flavors;
        if (!Array.isArray(selected) || !selected.length || selected.length > Object.keys(flavors).length
          || selected.some(flavor => typeof flavor !== 'string' || !Object.hasOwn(flavors, flavor))
          || selected.length !== new Set(selected).size) return { items: 'chooseFlavors' };
      }
      return {};
    }
    const items = order.supermarketItems;
    if (!items || kinds.some(kind => !Number.isInteger(items[kind]) || items[kind] < 0 || items[kind] > limits.supermarket)
      || items.cup + items.plate < 1) return { items: 'chooseItems' };
    return {};
  }

  function detailErrors(order, delivery) {
    const errors = {};
    const { customerName, phone, deliveryAddress, contactMethod, notes, governorateId, areaId } = order;
    if (typeof customerName !== 'string' || !/^[\p{L}\p{M}][\p{L}\p{M}\s.'’-]{1,79}$/u.test(customerName.trim())) {
      errors.customerName = 'invalidName';
    }
    if (!normalizePhone(phone)) errors.phone = 'invalidPhone';
    const { governorate, area } = lookup(delivery, governorateId, areaId);
    if (!governorate) errors.governorateId = 'chooseGovernorate';
    else if (!area) errors.areaId = 'chooseArea';
    if (typeof deliveryAddress !== 'string' || deliveryAddress.trim().length < 10 || deliveryAddress.trim().length > 500) {
      errors.deliveryAddress = 'invalidAddress';
    }
    if (!contactMethods.includes(contactMethod)) errors.contactMethod = 'chooseContact';
    if (notes !== undefined && (typeof notes !== 'string' || notes.trim().length > limits.notes)) {
      errors.notes = 'invalidNotes';
    }
    return errors;
  }

  globalThis.RashStore = { products, flavors, places, thresholds, limits, types, kinds, statuses, contactMethods,
    normalizePhone, lookup, calculate, itemErrors, detailErrors };
})();
