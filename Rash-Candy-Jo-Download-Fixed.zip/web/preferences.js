'use strict';

(() => {
  const root = document.documentElement;
  const system = matchMedia('(prefers-color-scheme: dark)');
  const values = {};
  function read(name) {
    try { return localStorage.getItem('rash-' + name); } catch { return values[name]; }
  }
  function set(name, value) {
    values[name] = value;
    try { localStorage.setItem('rash-' + name, value); } catch { /* File previews can restrict storage. */ }
    apply();
  }
  function apply() {
    root.lang = read('language') === 'en' ? 'en' : 'ar';
    root.dir = root.lang === 'ar' ? 'rtl' : 'ltr';
    const theme = read('theme');
    root.dataset.theme = theme === 'light' || theme === 'dark' ? theme : system.matches ? 'dark' : 'light';
  }
  apply();
  system.addEventListener('change', () => {
    apply();
    document.dispatchEvent(new Event('rash-theme'));
  });
  globalThis.RashPrefs = { set };
})();
