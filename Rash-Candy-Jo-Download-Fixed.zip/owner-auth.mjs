import { createHmac, randomBytes, scrypt, timingSafeEqual } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';

const derive = promisify(scrypt);
const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

export const dataDirectory = () => process.env.RASH_DATA_DIR
  ? resolve(process.env.RASH_DATA_DIR)
  : fileURLToPath(new URL('./.preview-data/', import.meta.url));

export function newTotpSecret() {
  let bits = 0;
  let buffer = 0;
  let result = '';
  for (const byte of randomBytes(20)) {
    buffer = (buffer << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      bits -= 5;
      result += alphabet[(buffer >>> bits) & 31];
    }
  }
  return result;
}

function base32(value) {
  let bits = 0;
  let buffer = 0;
  const bytes = [];
  for (const character of value) {
    buffer = (buffer << 5) | alphabet.indexOf(character);
    bits += 5;
    if (bits >= 8) {
      bits -= 8;
      bytes.push((buffer >>> bits) & 255);
    }
  }
  return Buffer.from(bytes);
}

export function totpCode(secret, counter) {
  const message = Buffer.alloc(8);
  message.writeBigUInt64BE(BigInt(counter));
  const digest = createHmac('sha1', base32(secret)).update(message).digest();
  const index = digest.at(-1) & 15;
  return String((digest.readUInt32BE(index) & 0x7fffffff) % 1_000_000).padStart(6, '0');
}

export function matchedTotp(secret, value, time = Date.now()) {
  if (typeof value !== 'string' || !/^\d{6}$/.test(value)) return null;
  const counter = Math.floor(time / 30_000);
  for (const offset of [0, -1, 1]) {
    const candidate = counter + offset;
    if (candidate >= 0 && safeEqual(totpCode(secret, candidate), value)) return candidate;
  }
  return null;
}

export function safeEqual(first, second) {
  const left = Buffer.from(first);
  const right = Buffer.from(second);
  return left.length === right.length && timingSafeEqual(left, right);
}

export async function createOwnerConfig(email, password, totpSecret = '') {
  email = email.trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) throw new Error('Enter a valid owner email.');
  if (password.length < 14 || password.length > 128) throw new Error('Use a password from 14 to 128 characters.');
  if (totpSecret && !/^[A-Z2-7]{32}$/.test(totpSecret)) throw new Error('Invalid authenticator secret.');
  const salt = randomBytes(16).toString('hex');
  const hash = await derive(password, salt, 64);
  return { email, salt, hash: hash.toString('hex'), totpSecret };
}

export function readOwnerConfig(file) {
  try {
    const config = JSON.parse(readFileSync(file, 'utf8'));
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(config.email) || !/^[a-f0-9]{32}$/.test(config.salt)
      || !/^[a-f0-9]{128}$/.test(config.hash) || !/^(?:[A-Z2-7]{32})?$/.test(config.totpSecret)) {
      throw new Error('Invalid owner configuration.');
    }
    return config;
  } catch (error) {
    if (error.code === 'ENOENT') return null;
    throw error;
  }
}

export async function checkPassword(owner, email, password) {
  if (typeof email !== 'string' || email.length > 254 || typeof password !== 'string' || password.length > 128) return false;
  const candidate = (await derive(password, owner.salt, 64)).toString('hex');
  return safeEqual(candidate, owner.hash) && email.trim().toLowerCase() === owner.email;
}

