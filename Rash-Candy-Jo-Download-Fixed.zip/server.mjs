import { createServer } from 'node:http';
import { createHash, randomBytes } from 'node:crypto';
import { mkdirSync, readFileSync, readdirSync, chmodSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { DatabaseSync } from 'node:sqlite';
import { checkPassword, dataDirectory, matchedTotp, readOwnerConfig, safeEqual } from './owner-auth.mjs';
import './web/store.js';
import './web/shared.js';

const { calculate, detailErrors, itemErrors, lookup, normalizePhone, kinds, statuses } = globalThis.RashStore;
const root = fileURLToPath(new URL('./', import.meta.url));
const web = join(root, 'web');
const [snapshot] = JSON.parse(readFileSync(join(root, 'originals/public-config.json'), 'utf8'));
const config = snapshot.result.data.json;
const delivery = config.settings.delivery;
const digest = value => createHash('sha256').update(value).digest('hex');
const orderCodePattern = /^RASH-\d{8}-[A-F0-9]{6}$/;
const tokenPattern = /^[a-f0-9]{64}$/i;
const uuidPattern = /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i;
const timezone = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Amman', year: 'numeric', month: '2-digit', day: '2-digit' });
const mime = {
  html: 'text/html; charset=utf-8', css: 'text/css; charset=utf-8', js: 'text/javascript; charset=utf-8',
  webp: 'image/webp', png: 'image/png', woff2: 'font/woff2', txt: 'text/plain; charset=utf-8',
};

class RequestError extends Error {
  constructor(status, fields) {
    super('Request rejected');
    this.status = status;
    this.fields = fields;
  }
}

function send(response, status, body, type, headers = {}) {
  response.writeHead(status, {
    'Content-Type': type,
    'Cache-Control': 'no-store',
    'Content-Security-Policy': "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self'; font-src 'self'; connect-src 'self'; base-uri 'none'; object-src 'none'; frame-ancestors 'none'; form-action 'self'",
    'Cross-Origin-Resource-Policy': 'same-origin',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=(), usb=(), browsing-topics=()',
    'Referrer-Policy': 'no-referrer',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'X-Robots-Tag': 'noindex, nofollow, noarchive',
    ...headers,
  });
  response.end(body);
}

function json(response, status, value, headers) {
  send(response, status, JSON.stringify(value), 'application/json; charset=utf-8', headers);
}

function rpcResult(response, value) {
  json(response, 200, [{ result: { data: { json: value } } }]);
}

function redirect(response, destination) {
  send(response, 303, '', mime.txt, { Location: destination });
}

async function requestBody(request) {
  if (request.headers['content-type']?.split(';', 1)[0].trim().toLowerCase() !== 'application/json') {
    throw new RequestError(415);
  }
  const max = 16_384;
  if (Number(request.headers['content-length']) > max) {
    request.resume();
    throw new RequestError(413);
  }
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > max) throw new RequestError(413);
    chunks.push(chunk);
  }
  try {
    const value = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error();
    return value;
  } catch {
    throw new RequestError(400);
  }
}

function permittedOrigin(request, configuredOrigin) {
  const { origin, host } = request.headers;
  if (configuredOrigin) return origin === configuredOrigin;
  const loopback = /^(?:localhost|127\.0\.0\.1|\[::1\])(?::\d+)?$/i.test(host || '');
  if (loopback && origin === 'http://' + host) return true;
  // The review harness terminates TLS before forwarding requests to the local-only listener.
  return process.env.SITES_MANAGED_LINUX_CONTAINER === '1' && Boolean(origin)
    && request.headers['sec-fetch-site'] === 'same-origin';
}

function orderFrom(body) {
  if (!body || typeof body.idempotencyKey !== 'string' || !uuidPattern.test(body.idempotencyKey)
    || typeof body.cancellationToken !== 'string' || !tokenPattern.test(body.cancellationToken)) {
    throw new RequestError(400);
  }
  const orderType = body.orderType;
  const extra = orderType === 'personal' ? 'personalItems' : 'supermarketItems';
  const permitted = ['idempotencyKey', 'cancellationToken', 'orderType', 'customerName', 'phone', 'governorateId',
    'areaId', 'deliveryAddress', 'contactMethod', 'notes', extra];
  if (Object.keys(body).some(key => !permitted.includes(key))) throw new RequestError(400);
  if (orderType === 'personal' && Array.isArray(body.personalItems)
    && body.personalItems.some(item => item && Object.keys(item).some(key => !['kind', 'flavors'].includes(key)))) throw new RequestError(400);
  if (orderType === 'supermarket' && body.supermarketItems
    && Object.keys(body.supermarketItems).some(key => !kinds.includes(key))) throw new RequestError(400);
  const fields = { ...itemErrors(body), ...detailErrors(body, delivery) };
  if (Object.keys(fields).length) throw new RequestError(400, fields);
  const { governorate, area } = lookup(delivery, body.governorateId, body.areaId);
  const amounts = calculate(body, delivery);
  return {
    orderType, customerName: body.customerName.trim(), phone: normalizePhone(body.phone),
    governorateId: governorate.id, governorateName: governorate.name, areaId: area.id, areaName: area.name,
    deliveryAddress: body.deliveryAddress.trim(), contactMethod: body.contactMethod,
    notes: body.notes?.trim() || '', scheduledAt: null, ...amounts,
    ...(orderType === 'personal'
      ? { personalItems: body.personalItems.map(({ kind, flavors }) => ({ kind, flavors })) }
      : { supermarketItems: { cup: body.supermarketItems.cup, plate: body.supermarketItems.plate } }),
  };
}

function files() {
  const mapping = new Map([
    ['/', 'index.html'], ['/privacy', 'privacy.html'], ['/404', '404.html'], ['/admin', 'admin.html'],
    ['/admin/sign-in', 'sign-in.html'],
    ...['preferences.js', 'shared.js', 'store.js', 'client.js', 'owner.js', 'utility.js', 'style.css'].map(name => ['/' + name, name]),
    ...readdirSync(join(web, 'assets')).filter(name => /^[a-z0-9_.-]+\.(?:webp|png|woff2|txt)$/i.test(name)).map(name =>
      ['/assets/' + name, 'assets/' + name]),
  ]);
  return new Map([...mapping].map(([route, path]) => {
    const data = readFileSync(join(web, path));
    return [route, {
      data: route === '/' ? data.toString().replace('<div class="product-grid" id="catalog"></div>',
        `<div class="product-grid" id="catalog" data-lang="ar">${RashUI.catalogMarkup('ar')}</div>`) : data,
      type: mime[path.split('.').at(-1)],
    }];
  }));
}

function limits() {
  const entries = new Map();
  return (key, count, duration) => {
    const now = Date.now();
    const previous = entries.get(key);
    if (!previous || previous.until <= now) {
      if (entries.size >= 2048) {
        for (const [id, item] of entries) {
          if (item.until <= now) entries.delete(id);
        }
        if (entries.size >= 2048) throw new RequestError(429);
      }
      entries.set(key, { attempts: 1, until: now + duration });
      return;
    }
    if (previous.attempts >= count) throw new RequestError(429);
    previous.attempts += 1;
  };
}

export function createPreviewServer({
  dataDir = dataDirectory(), configuredOrigin = process.env.RASH_PREVIEW_ORIGIN || '',
} = {}) {
  mkdirSync(dataDir, { recursive: true, mode: 0o700 });
  const dbPath = join(dataDir, 'orders.sqlite');
  const owner = readOwnerConfig(join(dataDir, 'owner.json'));
  const db = new DatabaseSync(dbPath);
  chmodSync(dbPath, 0o600);
  db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA busy_timeout = 3000;
    CREATE TABLE IF NOT EXISTS orders (
      code TEXT PRIMARY KEY, idempotency_key TEXT NOT NULL UNIQUE, cancel_hash TEXT NOT NULL,
      fingerprint TEXT NOT NULL, data TEXT NOT NULL, created_at TEXT NOT NULL,
      status TEXT NOT NULL CHECK(status IN ('pending','confirmed','cancelled')), revision INTEGER NOT NULL DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS orders_date ON orders(created_at DESC, code DESC);
    CREATE TABLE IF NOT EXISTS used_totp (owner_key TEXT PRIMARY KEY, counter INTEGER NOT NULL);
  `);
  const insert = db.prepare(`INSERT INTO orders (code,idempotency_key,cancel_hash,fingerprint,data,created_at,status)
    VALUES (?,?,?,?,?,?,'pending') ON CONFLICT DO NOTHING`);
  const byKey = db.prepare('SELECT code, fingerprint, cancel_hash FROM orders WHERE idempotency_key = ?');
  const byCode = db.prepare('SELECT cancel_hash, status FROM orders WHERE code = ?');
  const cancel = db.prepare("UPDATE orders SET status = 'cancelled', revision = revision + 1 WHERE code = ? AND status <> 'cancelled'");
  const list = db.prepare('SELECT code, data, created_at, status, revision FROM orders ORDER BY created_at DESC, code DESC LIMIT 31 OFFSET ?');
  const change = db.prepare('UPDATE orders SET status = ?, revision = revision + 1 WHERE code = ? AND revision = ?');
  const totpOnce = db.prepare(`INSERT INTO used_totp (owner_key,counter) VALUES (?,?)
    ON CONFLICT(owner_key) DO UPDATE SET counter=excluded.counter WHERE used_totp.counter < excluded.counter`);
  const assets = files();
  const limit = limits();
  const sessions = new Map();
  const sessionDuration = 60 * 60 * 1000;
  const networkKey = randomBytes(16).toString('hex');
  const secureCookie = configuredOrigin.startsWith('https://');
  const cookieName = secureCookie ? '__Host-rash-owner' : 'rash-owner';

  function sessionKey(request) {
    const cookies = request.headers.cookie?.split(';').map(cookie => cookie.trim()) || [];
    const key = cookies.find(cookie => cookie.startsWith(cookieName + '='))?.slice(cookieName.length + 1);
    return tokenPattern.test(key || '') ? digest(key) : null;
  }
  function authorized(request) {
    const key = sessionKey(request);
    const expiry = key && sessions.get(key);
    if (expiry && expiry > Date.now()) return true;
    if (key) sessions.delete(key);
    return false;
  }
  function cookie(key, age) {
    return `${cookieName}=${key}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${age}${secureCookie ? '; Secure' : ''}`;
  }
  function render(response, route, status = 200) {
    const file = assets.get(route);
    const cache = route.startsWith('/assets/') ? 'public, max-age=86400' : 'no-store';
    send(response, status, file.data, file.type, { 'Cache-Control': cache,
      ...(secureCookie ? { 'Strict-Transport-Security': 'max-age=31536000' } : {}) });
  }

  const server = createServer({ requestTimeout: 12_000, headersTimeout: 10_000 }, async (request, response) => {
    let route = '';
    const ip = digest(networkKey + (request.socket.remoteAddress || ''));
    try {
      const url = new URL(request.url, 'http://localhost');
      route = url.pathname;
      const method = request.method;
      if (method === 'GET' || method === 'HEAD') {
        if (route === '/robots.txt') { send(response, 200, 'User-agent: *\nDisallow: /\n', mime.txt); return; }
        if (route === '/healthz') { json(response, 200, { status: 'ok', mode: 'review' }); return; }
        if (route === '/api/trpc/site.publicConfig') { rpcResult(response, config); return; }
        if (route === '/api/owner/orders') {
          if (!authorized(request)) throw new RequestError(401);
          const page = Number(url.searchParams.get('page') || 0);
          if (!Number.isInteger(page) || page < 0 || page > 10000) throw new RequestError(400);
          const rows = list.all(page * 30);
          json(response, 200, { hasNext: rows.length > 30, orders: rows.slice(0, 30).map(row => ({
            ...JSON.parse(row.data), orderCode: row.code, createdAt: row.created_at, status: row.status, revision: row.revision,
          })) });
          return;
        }
        if (route === '/admin') {
          if (!authorized(request)) redirect(response, '/admin/sign-in');
          else render(response, route);
          return;
        }
        if (route === '/admin/sign-in' && authorized(request)) { redirect(response, '/admin'); return; }
        if (assets.has(route)) { render(response, route, route === '/404' ? 404 : 200); return; }
        render(response, '/404', 404);
        return;
      }
      if (method !== 'POST') throw new RequestError(405);

      const checkout = ['/api/trpc/orders.create', '/api/trpc/orders.cancel'].includes(route);
      const ownerPost = ['/api/owner/login', '/api/owner/logout', '/api/owner/orders/status'].includes(route);
      if (!checkout && !ownerPost) throw new RequestError(404);
      if (!permittedOrigin(request, configuredOrigin)) throw new RequestError(403);
      if (ownerPost && route !== '/api/owner/login' && !authorized(request)) throw new RequestError(401);
      if (checkout) limit('order:' + ip, 30, 60_000);
      if (route === '/api/owner/login') {
        if (!owner) throw new RequestError(503);
        limit('login:' + ip, 8, 15 * 60_000);
        limit('login:all', 24, 15 * 60_000);
      }
      const body = await requestBody(request);
      const input = body?.[0]?.json;
      if (route === '/api/trpc/orders.create') {
        const data = orderFrom(input);
        const serialized = JSON.stringify(data);
        const fingerprint = digest(serialized);
        const cancelHash = digest(input.cancellationToken);
        const now = new Date();
        const day = timezone.formatToParts(now).filter(part => part.type !== 'literal').map(part => part.value).join('');
        const key = input.idempotencyKey.toLowerCase();
        let row = byKey.get(key);
        for (let attempt = 0; !row && attempt < 3; attempt += 1) {
          const code = 'RASH-' + day + '-' + randomBytes(3).toString('hex').toUpperCase();
          insert.run(code, key, cancelHash, fingerprint, serialized, now.toISOString());
          row = byKey.get(key);
        }
        if (!row) throw new RequestError(503);
        if (!safeEqual(row.fingerprint, fingerprint) || !safeEqual(row.cancel_hash, cancelHash)) throw new RequestError(409);
        rpcResult(response, { orderCode: row.code });
        return;
      }
      if (route === '/api/trpc/orders.cancel') {
        if (!input || typeof input.orderCode !== 'string' || !orderCodePattern.test(input.orderCode)
          || typeof input.cancellationToken !== 'string' || !tokenPattern.test(input.cancellationToken)) throw new RequestError(400);
        const row = byCode.get(input.orderCode);
        if (!row || !safeEqual(row.cancel_hash, digest(input.cancellationToken))) throw new RequestError(404);
        cancel.run(input.orderCode);
        rpcResult(response, { cancelled: true });
        return;
      }
      if (route === '/api/owner/login') {
        const good = await checkPassword(owner, body.email, body.password);
        if (!good) throw new RequestError(401);
        if (owner.totpSecret) {
          const counter = matchedTotp(owner.totpSecret, body.totp);
          if (counter === null || !totpOnce.run(digest(owner.totpSecret), counter).changes) throw new RequestError(401);
        }
        const now = Date.now();
        for (const [key, expiry] of sessions) if (expiry <= now) sessions.delete(key);
        if (sessions.size >= 24) sessions.delete(sessions.keys().next().value);
        const previous = sessionKey(request);
        if (previous) sessions.delete(previous);
        const key = randomBytes(32).toString('hex');
        sessions.set(digest(key), now + sessionDuration);
        json(response, 200, { signedIn: true }, { 'Set-Cookie': cookie(key, sessionDuration / 1000) });
        return;
      }
      if (route === '/api/owner/logout') {
        sessions.delete(sessionKey(request));
        json(response, 200, { signedOut: true }, { 'Set-Cookie': cookie('', 0) });
        return;
      }
      if (typeof body.orderCode !== 'string' || !orderCodePattern.test(body.orderCode) || !statuses.includes(body.status)
        || !Number.isSafeInteger(body.revision) || body.revision < 0) throw new RequestError(400);
      if (!change.run(body.status, body.orderCode, body.revision).changes) throw new RequestError(409);
      json(response, 200, { updated: true });
    } catch (error) {
      if (response.headersSent || response.destroyed) return;
      const status = error.status || 500;
      if (route.startsWith('/api/trpc/')) {
        json(response, status, [{ error: { json: { message: 'Request failed', data: { httpStatus: status, fields: error.fields } } } }]);
      } else {
        json(response, status, { error: 'Request failed' });
      }
    }
  });
  server.on('close', () => db.close());
  return server;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT || 4173);
  const host = process.env.HOST || '127.0.0.1';
  const external = !['127.0.0.1', 'localhost', '::1'].includes(host);
  const configuredOrigin = process.env.RASH_PREVIEW_ORIGIN || '';
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('Invalid PORT.');
  if (!['127.0.0.1', 'localhost', '::1', '0.0.0.0', '::'].includes(host)) throw new Error('Invalid HOST.');
  // Public previews must be explicitly configured. Never silently use an ephemeral order database.
  if (external) {
    let validOrigin = false;
    try {
      const url = new URL(configuredOrigin);
      validOrigin = url.protocol === 'https:' && url.origin === configuredOrigin && !url.username && !url.password;
    } catch {}
    if (!validOrigin) throw new Error('Public preview requires an exact HTTPS RASH_PREVIEW_ORIGIN.');
    if (!process.env.RASH_DATA_DIR) throw new Error('Public preview requires RASH_DATA_DIR on persistent storage.');
  }
  createPreviewServer({ configuredOrigin }).listen(port, host, () => {
    process.stdout.write(`Rash Candy Jo review listening on ${host}:${port}\n`);
  });
}

