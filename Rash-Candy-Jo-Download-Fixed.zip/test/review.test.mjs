import assert from 'node:assert/strict';
import { test, before, after } from 'node:test';
import { mkdtempSync, rmSync, writeFileSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { randomBytes, randomUUID } from 'node:crypto';
import { createPreviewServer } from '../server.mjs';
import { createOwnerConfig, matchedTotp, totpCode } from '../owner-auth.mjs';
import '../web/store.js';

const { normalizePhone, products, flavors, thresholds, calculate, itemErrors } = globalThis.RashStore;
const snapshot = JSON.parse(readFileSync(new URL('../originals/public-config.json', import.meta.url)))[0].result.data.json;
const { delivery } = snapshot.settings;
const dir = mkdtempSync(join(tmpdir(), 'rash-review-test-'));
const email = 'test-owner@example.test';
const password = 'review-only-local-password';
const totpSecret = 'GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ';
let app, origin, cookie;
let orderCode;
const draft = (changes = {}) => ({
  idempotencyKey: randomUUID(), cancellationToken: randomBytes(32).toString('hex'),
  orderType: 'personal', customerName: 'اختبار المتجر', phone: '٠٧٩ ٠٠٠-٠٠٠٠',
  governorateId: 'amman', areaId: 'customer-location', deliveryAddress: 'عنوان محلي تجريبي للفحص',
  contactMethod: 'whatsapp', notes: '<img src=x onerror=alert(1)>',
  personalItems: [{ kind: 'cup', flavors: ['جيلي'] }, { kind: 'plate', flavors: ['شوكولاتة', 'كراميل'] }],
  ...changes,
});
const sharedDraft = draft();
const rpc = (method, body) => post('/api/trpc/' + method + '?batch=1', { 0: { json: body } });
const post = (path, body, headers = {}) => fetch(origin + path, {
  method: 'POST', headers: { Origin: origin, 'Content-Type': 'application/json', ...headers }, body: JSON.stringify(body),
});

before(async () => {
  const owner = await createOwnerConfig(email, password, totpSecret);
  writeFileSync(join(dir, 'owner.json'), JSON.stringify(owner), { mode: 0o600 });
  app = createPreviewServer({ dataDir: dir });
  await new Promise(resolve => app.listen(0, '127.0.0.1', resolve));
  origin = 'http://127.0.0.1:' + app.address().port;
});
after(async () => {
  if (app) await new Promise(resolve => app.close(resolve));
  rmSync(dir, { recursive: true, force: true });
});

test('published catalog, flavors, delivery fees and thresholds match the captured public store', async () => {
  assert.deepEqual(Object.values(products.personal).map(p => [p.ar, p.price, p.detail[0]]), [['كاسة', 200, 'أكثر من ربع كيلو'], ['صحن', 400, 'أكثر من نصف كيلو']]);
  assert.deepEqual(Object.values(products.supermarket).map(p => [p.ar, p.price, p.detail[0]]), [['كاسة كاندي', 75, 'كاسة حلوى مشكلة'], ['صحن كاندي', 300, '36 حبة']]);
  assert.deepEqual(Object.keys(flavors), ['جيلي','مارشميلو','شوكولاتة','علكة','حلقوم','سكاكر ملونة','لوليبوب','كراميل']);
  assert.deepEqual(thresholds, { personal: 1000, supermarket: 3000 });
  assert.equal(delivery.length, 12);
  const response = await fetch(origin + '/api/trpc/site.publicConfig');
  assert.deepEqual((await response.json())[0].result.data.json, snapshot);
  const normal = calculate(sharedDraft, delivery);
  assert.deepEqual(normal, { subtotal: 600, deliveryFee: 200, total: 800 });
  assert.equal(calculate({ ...sharedDraft, governorateId: 'zarqa' }, delivery).deliveryFee, 200);
  assert.equal(calculate({ ...sharedDraft, governorateId: 'irbid' }, delivery).deliveryFee, 250);
  assert.equal(calculate({ ...sharedDraft, areaId: 'amman-arab-university' }, delivery).deliveryFee, 0);
  assert.equal(calculate({ ...sharedDraft, governorateId: '' }, delivery).total, null);
  assert.equal(calculate({ ...sharedDraft, personalItems: Array(5).fill({ kind: 'cup' }) }, delivery).deliveryFee, 0);
  const retail = { orderType: 'supermarket', governorateId: 'aqaba', areaId: 'customer-location', supermarketItems: { cup: 4, plate: 9 } };
  assert.equal(calculate(retail, delivery).deliveryFee, 0);
  assert.equal(calculate({ ...retail, supermarketItems: { cup: 3, plate: 9 } }, delivery).deliveryFee, 250);
});

test('Jordanian phone normalization accepts the existing mobile ranges and digit formats', () => {
  for (const input of ['079 000 0000','+962-79-0000000','00962790000000','790000000','٠٧٩ ٠٠٠-٠٠٠٠','۰۷۹۰۰۰۰۰۰۰']) {
    assert.equal(normalizePhone(input), '+962790000000');
  }
  for (const input of ['+1 202 555 0144','06 555 5555','0750000000','+9620790000000','07912345','079000000x']) {
    assert.equal(normalizePhone(input), null);
  }
  assert.equal(itemErrors({ orderType:'personal', personalItems: [{ kind:'cup', flavors:['جيلي','جيلي'] }] }).items,'chooseFlavors');
  assert.equal(itemErrors({ orderType:'supermarket', supermarketItems:{ cup:100, plate:0 } }).items,'chooseItems');
});

test('guest orders validate on server, calculate totals and handle concurrent retries', async () => {
  assert.equal((await rpc('orders.create', draft({ phone: '+12025550144' }))).status, 400);
  assert.equal((await rpc('orders.create', draft({ areaId: 'not-an-area' }))).status, 400);
  assert.equal((await rpc('orders.create', draft({ total: 1 }))).status, 400);
  assert.equal((await rpc('orders.create', draft({ notes: 'x'.repeat(501) }))).status, 400);
  assert.equal((await rpc('orders.create', draft({ personalItems: [{ kind: 'cup', flavors: [] }] }))).status, 400);
  const results = await Promise.all([rpc('orders.create', sharedDraft), rpc('orders.create', sharedDraft)]);
  assert.deepEqual(results.map(response => response.status), [200, 200]);
  const [one, two] = await Promise.all(results.map(response => response.json()));
  assert.deepEqual(one, two);
  orderCode = one[0].result.data.json.orderCode;
  assert.match(orderCode, /^RASH-\d{8}-[A-F0-9]{6}$/);
  assert.equal((await rpc('orders.create', { ...sharedDraft, notes: 'different notes' })).status, 409);
  const retail = draft({ orderType: 'supermarket', governorateId: 'irbid', supermarketItems: { cup: 4, plate: 9 } });
  delete retail.personalItems;
  assert.equal((await rpc('orders.create', retail)).status, 200);
});

test('unauthenticated order access, traversal, and cross-origin writes are denied', async () => {
  const route = await fetch(origin + '/admin', { redirect: 'manual' });
  assert.equal(route.status, 303);
  assert.equal(route.headers.get('location'), '/admin/sign-in');
  assert.equal((await fetch(origin + '/api/owner/orders')).status, 401);
  assert.equal((await post('/api/owner/orders/status', { orderCode, revision: 0, status: 'confirmed' })).status, 401);
  assert.equal((await post('/api/trpc/orders.create', {}, { Origin: 'https://another.example' })).status, 403);
  for (const path of ['/.git/config', '/git', '/.env', '/server.mjs', '/originals/public-config.json', '/.preview-data/owner.json',
    '/assets/%2e%2e/.git/config', '/assets/%2e%2e%2f.git/config', '/assets/index.js.map', '/assets/']) {
    assert.equal((await fetch(origin + path)).status, 404, path);
  }
  const health = await fetch(origin + '/healthz');
  assert.equal(health.status, 200);
  assert.deepEqual(await health.json(), { status: 'ok', mode: 'review' });
  assert.equal(health.headers.get('cache-control'), 'no-store');
  const privacy = await fetch(origin + '/privacy');
  assert.equal(privacy.status, 200);
  assert.match(await privacy.text(), /سياسة الخصوصية/);
  assert.match(privacy.headers.get('content-security-policy'), /frame-ancestors 'none'/);
  assert.equal(privacy.headers.get('referrer-policy'), 'no-referrer');
});

test('owner MFA, replay prevention, private data, status changes, cancellation and logout', async () => {
  assert.equal(totpCode(totpSecret, 1), '287082'); // Six-digit truncation of the RFC 6238 SHA-1 vector.
  assert.equal(matchedTotp(totpSecret, '287082', 59_000), 1);
  const otp = totpCode(totpSecret, Math.floor(Date.now() / 30_000));
  assert.equal((await post('/api/owner/login', { email, password })).status, 401);
  const signedIn = await post('/api/owner/login', { email, password, totp: otp });
  assert.equal(signedIn.status, 200);
  assert.match(signedIn.headers.get('set-cookie'), /HttpOnly; SameSite=Strict/);
  cookie = signedIn.headers.get('set-cookie').split(';')[0];
  assert.equal((await post('/api/owner/login', { email, password, totp: otp })).status, 401);
  const headers = { Cookie: cookie };
  assert.equal((await fetch(origin + '/admin', { headers })).status, 200);
  const response = await fetch(origin + '/api/owner/orders', { headers });
  assert.equal(response.headers.get('cache-control'), 'no-store');
  const { orders } = await response.json();
  assert.equal(orders.length, 2);
  const order = orders.find(item => item.orderCode === orderCode);
  assert.deepEqual([order.subtotal, order.deliveryFee, order.total, order.phone], [600, 200, 800, '+962790000000']);
  assert.deepEqual(order.personalItems, sharedDraft.personalItems);
  assert.equal(order.notes, sharedDraft.notes);
  assert.ok(!Object.hasOwn(order, 'cancellationToken'));
  assert.equal(orders.find(item => item.orderType === 'supermarket').total, 3000);
  const update = { orderCode, revision: order.revision, status: 'confirmed' };
  assert.equal((await post('/api/owner/orders/status', update, headers)).status, 200);
  assert.equal((await post('/api/owner/orders/status', update, headers)).status, 409);
  assert.equal((await rpc('orders.cancel', { orderCode, cancellationToken: '0'.repeat(64) })).status, 404);
  const cancel = { orderCode, cancellationToken: sharedDraft.cancellationToken };
  assert.equal((await rpc('orders.cancel', cancel)).status, 200);
  assert.equal((await rpc('orders.cancel', cancel)).status, 200);
  const rows = (await (await fetch(origin + '/api/owner/orders', { headers })).json()).orders;
  assert.equal(rows.find(item => item.orderCode === orderCode).status, 'cancelled');
  assert.equal((await post('/api/owner/logout', {}, headers)).status, 200);
  assert.equal((await fetch(origin + '/api/owner/orders', { headers })).status, 401);
});

