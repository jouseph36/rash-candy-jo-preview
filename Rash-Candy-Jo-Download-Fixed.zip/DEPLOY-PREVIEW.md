# Rash Candy Jo — isolated review deployment

**Status: ready to configure, NOT deployed.** This package is for a separate test domain only. It does not modify the existing Manus shop or connect to its database. Test orders must use fictional customer information. Do not advertise the review URL to customers.

## What is included

- Responsive bilingual storefront, exact archived product data and preserved source imagery
- Guest test checkout and cancellation backed by SQLite
- Owner dashboard at `/admin`, disabled until credentials are provisioned
- Rate limiting, strict origin checks, CSP, noindex headers, and isolated private order files
- `/healthz` endpoint for readiness checks, with no customer data
- A read-only, self-contained offline storefront preview in `dist/Rash-Candy-Jo-Preview.html` (no server or order saving)

## Deploy on a separate Railway test service

1. Connect Railway and create an **independent** service using the contents of the `rash-candy-jo` folder as its project root (not the current production site). Railway detects `Dockerfile` and uses Node 24. This Dockerfile drops privileges to the `node` user after setting mounted-data ownership.
2. Create a persistent Railway volume and mount it at `/app/.preview-data`. Keep **one service replica** for the SQLite database. Configure backups and a retention policy before using any non-test data.
3. In the service variables, set:

   ```text
   HOST=0.0.0.0
   RASH_DATA_DIR=/app/.preview-data
   RASH_PREVIEW_ORIGIN=https://YOUR-PREVIEW-DOMAIN
   ```

   The origin must be the exact public HTTPS origin without trailing `/` or a path, e.g. `https://example.up.railway.app`. The platform supplies `PORT`; do not hardcode a production port. Update `RASH_PREVIEW_ORIGIN` if the preview domain changes.
4. Generate a Railway public HTTPS domain for this *preview service*. Set the healthcheck path to `/healthz`. The server refuses public startup if HTTPS origin or explicit data directory is missing.
5. To enable the owner portal, run `node scripts/setup-owner.mjs` **inside a private interactive service shell** with access to the mounted volume. Choose a unique 14+ character password and enable authenticator-based MFA. Don't put passwords or authenticator secrets in Git, chat messages, logs, or a screenshot. Restart the service so it loads `owner.json` and test `/admin`. If an interactive private shell is unavailable, keep owner login disabled until a secure setup path exists.
6. Test the new HTTPS domain: GET `/healthz` returns `{"status":"ok","mode":"review"}`, the storefront loads, dark/light and AR/EN switches work, create a fictional order, cancel it, and test owner login plus order status changes. Inspect mobile browsers and browser consoles. Verify the public domain returns `noindex` and blocks private files.
7. **Do not point the existing store domain at this service.** No production orders, live WhatsApp notification, payment gateway, or integration with Manus is configured by this package.

Official platform docs: [Railway volumes](https://docs.railway.com/volumes), [Dockerfile deployments](https://docs.railway.com/builds/dockerfiles).

## Local setup (no Railway needed)

```bash
npm test
npm run build
node server.mjs
```

Open `http://127.0.0.1:4173` and `/healthz`. Default host is loopback; no public domain is created by the command above. Docker builds require a working Docker engine and an internet connection to obtain `node:24-bookworm-slim` and its packaged runtime dependencies.

## Launch blockers before replacing the actual shop

- Full live source project, authoritative prices and delivery areas, and exact real back-end workflows from Manus
- Confirmed owner contact information, preparation times, allergen ingredient disclosures, customizations and order confirmation rules
- Completed bilingual privacy disclosure including legal operator, data retention, deletion, hosting and contact procedure
- Production-quality external testing (iOS/Safari, Android, inline social browsers), security review, monitoring and backup restoration
- Explicit owner approval before any modification or replacement of the current shop
