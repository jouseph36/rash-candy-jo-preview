import { mkdirSync, existsSync, writeFileSync, renameSync } from 'node:fs';
import { join } from 'node:path';
import { createInterface } from 'node:readline/promises';
import { Writable } from 'node:stream';
import { randomBytes } from 'node:crypto';
import { dataDirectory, createOwnerConfig, newTotpSecret, matchedTotp } from '../owner-auth.mjs';

if (!process.stdin.isTTY || !process.stdout.isTTY) {
  process.stderr.write('Run this setup from a private interactive terminal.\n');
  process.exit(1);
}
const directory = dataDirectory();
const destination = join(directory, 'owner.json');
const rotate = process.argv.includes('--rotate');
if (existsSync(destination) && !rotate) {
  process.stderr.write('The local owner is configured. Use --rotate to replace the local credentials.\n');
  process.exit(1);
}

let muted = false;
const output = new Writable({
  write(chunk, _encoding, next) {
    if (!muted) process.stdout.write(chunk);
    next();
  },
});
const terminal = createInterface({ input: process.stdin, output, terminal: true });
terminal.on('SIGINT', () => process.exit(130));

async function askSecret(prompt) {
  process.stdout.write(prompt);
  muted = true;
  try { return await terminal.question(''); }
  finally { muted = false; process.stdout.write('\n'); }
}

try {
  const email = await terminal.question('Owner email: ');
  const password = await askSecret('New password (14 to 128 characters): ');
  if (password !== await askSecret('Repeat password: ')) throw new Error('Passwords did not match.');
  const enable = (await terminal.question('Enable authenticator app (recommended) [Y/n]? ')).trim().toLowerCase();
  const secret = enable === 'n' ? '' : newTotpSecret();
  if (secret) {
    process.stdout.write(`\nAdd a time-based account in your authenticator. Keep this key private.\nKey: ${secret}\n6 digits, 30 seconds, SHA-1.\n`);
    const code = await askSecret('Current authenticator code: ');
    if (matchedTotp(secret, code.trim()) === null) throw new Error('The authenticator code did not match. Run setup again.');
  }
  const configuration = await createOwnerConfig(email, password, secret);
  mkdirSync(directory, { recursive: true, mode: 0o700 });
  const target = rotate ? destination + '.' + randomBytes(12).toString('hex') : destination;
  writeFileSync(target, JSON.stringify(configuration), { mode: 0o600, flag: 'wx' });
  if (rotate) renameSync(target, destination);
  process.stdout.write('Local owner setup saved. Restart the local server and open /admin.\n');
} catch (error) {
  process.stderr.write(error.message + '\n');
  process.exitCode = 1;
} finally {
  terminal.close();
}

