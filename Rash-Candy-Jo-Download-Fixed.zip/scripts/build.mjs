import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import '../web/store.js';
import '../web/shared.js';

const root = fileURLToPath(new URL('../', import.meta.url));
const web = join(root, 'web');
const dist = join(root, 'dist');
const config = JSON.parse(readFileSync(join(root, 'originals/public-config.json'), 'utf8'))[0].result.data.json;
const mime = { webp: 'image/webp', png: 'image/png', woff2: 'font/woff2' };
const toData = (name) => 'data:' + mime[name.split('.').at(-1)] + ';base64,'
  + readFileSync(join(web, 'assets', name)).toString('base64');
const hash = (text) => "'sha256-" + createHash('sha256').update(text).digest('base64') + "'";
const scriptHashes = [];

const css = readFileSync(join(web, 'style.css'), 'utf8')
  .replace(/url\('\/assets\/([^']+)'\)/g, (_all, name) => `url('${toData(name)}')`);
const bootstrap = `globalThis.RashOfflineAssets=Object.fromEntries(Array.from(document.querySelectorAll('[data-product-image]'), img => [img.dataset.productImage, img.getAttribute('src')]));globalThis.RashOfflineConfig=${JSON.stringify(config)};`
  .replace(/</g, '\\u003c');
const inline = (content) => {
  scriptHashes.push(hash(content));
  return '<script>' + content + '</script>';
};
const html = readFileSync(join(web, 'index.html'), 'utf8')
  .replace('<meta name="rash-mode" content="server">', '<meta name="rash-mode" content="offline">\n  <!-- CSP -->')
  .replace(/<script src="\/preferences.js"><\/script>/, () => inline(readFileSync(join(web, 'preferences.js'), 'utf8')))
  .replace('<link rel="stylesheet" href="/style.css">', () => '<style>' + css + '</style>')
  .replace(/\s*<script defer src="\/[^"]+"><\/script>/g, '')
  .replace(/\s+srcset="[^"]*"\s+sizes="[^"]*"/g, '')
  .replace(/(["'])\/assets\/([^"']+)\1/g, (_all, quote, name) => quote + toData(name) + quote)
  .replace('href="/privacy" data-privacy', 'href="#privacy" data-privacy')
  .replace('href="/" data-home', 'href="#main" data-home')
  .replace('<div class="product-grid" id="catalog"></div>', () =>
    `<div class="product-grid" id="catalog" data-lang="ar">${RashUI.catalogMarkup('ar', toData, false)}</div>`)
  .replace('</body>', () => [bootstrap, ...['store.js', 'shared.js', 'client.js'].map(file => readFileSync(join(web, file), 'utf8'))]
    .map(inline).join('\n') + '\n</body>');
const csp = [
  "default-src 'none'", 'script-src ' + scriptHashes.join(' '), 'style-src ' + hash(css), 'img-src data:',
  'font-src data:', "connect-src 'none'", "base-uri 'none'", "form-action 'none'",
].join('; ');
mkdirSync(dist, { recursive: true });
writeFileSync(join(dist, 'Rash-Candy-Jo-Preview.html'), html.replace('<!-- CSP -->', `<meta http-equiv="Content-Security-Policy" content="${csp}">`));
process.stdout.write('Built dist/Rash-Candy-Jo-Preview.html\n');

