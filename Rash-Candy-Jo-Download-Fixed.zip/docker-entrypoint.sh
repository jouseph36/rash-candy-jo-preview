#!/bin/sh
set -eu
# Railway volumes start owned by root; grant the private data dir to the unprivileged app user.
DATA_DIR="${RASH_DATA_DIR:-/app/.preview-data}"
mkdir -p "$DATA_DIR"
chown -R node:node "$DATA_DIR"
chmod 700 "$DATA_DIR"
exec gosu node "$@"
